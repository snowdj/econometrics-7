function [gamma_ape, V_ape, theta_hat, VCOV_theta_hat, prc_trim] = PanelCRC(Y, X, W, h, NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent)

% This function computes point estimates and standard errors for the
% correlated random coefficients model described by Graham and Powell
% (2009). It computes point estimates and standard errors for both the 
% just-identified (T=P) case and the overidentified case (T>P).

% Y         : N x T matrix of outcomes
% X         : N x PT matrix of regressors (including constant)
% W         : N x QT matrix of "time shifters"
% h         : bandwidth
% NG        : G x 1 vector with number of units in each of G "clusters"
% PI_mat    : N x PL matrix specifying the PI(X) matrix defining first
%             part of gamma0 (if this matrix is empty just estimate beta alone)
% PI_mat_d  : N x QL matrix specifying the PI(X) matrix defining second
%             part of gamma0 (if this matrix is empty just use first part in estimation)
% E         : if non empty program tests H0 : E*delta = 0 using a wald test

[N T]   = size(Y);
[N PT]  = size(X);  P = PT/T;
[N QT]  = size(W);  Q = QT/T;
[J QT]  = size(E);
G       = length(NG);
clear PT QT;

% if PI_mat is empty assume user wants to estimate beta directly
% and define PI_mat accordingly
if isempty(PI_mat)==1
    PI_mat = reshape(eye(P),1,P^2);
    PI_mat = repmat(PI_mat,N,1);
    PI_mat_d = [];
    L = P;
else
    [N LP]  = size(PI_mat); 
    L = LP/P;
    clear LP;
end

if T==P
%-----------------------------------------------------------------------%    
%-   JUST IDENTIFIED CASE (T=P): Graham and Powell (2009) estimators   -%
%-----------------------------------------------------------------------%

    %-----------------------------------------------------------------------%
    %- STEP 1 : PREPARE DATA FOR ESTIMATION                                -%
    %-----------------------------------------------------------------------%

    X = reshape(X',P,N*T);                      % rehape into a P x NT matrix
    W = reshape(W',Q,N*T);                      % rehape into a Q x NT matrix
    PI_mat = reshape(PI_mat',P,N*L);            % rehape into a P x NL matrix  
    Z = zeros((T+L)*N,Q+L);                     % (T+L)*N x Q + L `instrument' matrix
    R = zeros((T+L)*N,Q+L);                     % (T+L)*N x Q + L `regressor' matrix
    Yr= zeros((T+L)*N,1);                       % (T+L)*N x 1 `outcome' matrix
    det_XX = zeros(N,1);                        % vector of unit-specific design matrix determinants
    
    % outcome, regressor and instrument matrices for `naive' Chamberlain
    % estimator
    Zn = zeros(L*N,L);                          % L*N x L `instrument' matrix
    Rn = zeros(L*N,L);                          % L*N x L `regressor' matrix
    Yn = zeros(L*N,1);                          % L*N x 1 `outcome' matrix
   
    for i = 1:N    
        Y_i = Y(i,:)';                          %T x 1 vector of outcomes for the ith unit
        W_i = W(:,((i-1)*T + 1):(i*T))';        %T x Q time shifter regressor matrix for unit i
        X_i = X(:,((i-1)*T + 1):(i*T))';        %T x P policy regressor matrix for unit i
        PI_i = PI_mat(:,((i-1)*L + 1):(i*L))';  %L x P PI_matrix which defines gamma     
        X_adj_i = adj(X_i);                     %T x P (=T) adjoint matrix of X for unit i
        D(i) = det(X_i);                        % determinant of X matrix for ith unit                      
               
        % ith unit's contribution to instrument and regressor matrix (trimmed case)     
        Yr((T+L)*(i-1)+1:(T+L)*i) =  [(abs(D(i))<=h)*X_adj_i*Y_i; (abs(D(i))>h)*PI_i*(X_adj_i/D(i))*Y_i];
        Z((T+L)*(i-1)+1:(T+L)*i,:) = [(abs(D(i))<=h)*X_adj_i*W_i zeros(T,L); zeros(L,Q) (abs(D(i))>h)*eye(L)];
        R((T+L)*(i-1)+1:(T+L)*i,:) = [(abs(D(i))<=h)*X_adj_i*W_i zeros(T,L); (abs(D(i))>h)*PI_i*(X_adj_i/D(i))*W_i (abs(D(i))>h)*eye(L)];       
        
        % ith unit's contribution to instrument and regressor matrix (naive case)     
        Yn(L*(i-1)+1:L*i) = PI_i*(X_adj_i/D(i))*Y_i;
        Zn(L*(i-1)+1:L*i,:) = eye(L);
        Rn(L*(i-1)+1:L*i,:) = eye(L);             
        
    end        
    
    clear W_i X_i Y_i PI_i X_adj_i;

    prc_trim = 100*mean((abs(D)<=h));       %percent of observations used to tie down trend terms (i.e., percent `stayers')
    
    %-----------------------------------------------------------------%
    %- STEP 2 : ESTIMATE BY "TSLS"                                   -%
    %-----------------------------------------------------------------%   
    
    if h>0        
              
        theta_hat = Z'*R \ Z'*Yr;
        U = Yr - R*theta_hat;            %N(T+L) x 1 vector of residuals       
        
        if isempty(PI_mat_d)==1
            %-------------------------------------%
            %- CASE 1 : PI_mat_d matrix is empty -%
            %-------------------------------------%
        
            % estimate variance-covariance matrix
            OMEGA_hat = zeros(Q+L,Q+L);
            LAMBDA_hat = -Z'*R/G;        
        
            for g = 1:1:G     
                % upper & lower bounds for the g-th group                
                n1 = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + 1;                 
                n2 = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + (T+L)*NG(g);                
                
                U_g = U(n1:n2); 
                Z_g = Z(n1:n2,:);
    
                OMEGA_hat = OMEGA_hat + Z_g'*U_g*U_g'*Z_g/G;    
            end
            clear n1 n2 U_g Z_g stayers;
            
            VCOV_theta_hat= inv(LAMBDA_hat)*OMEGA_hat*inv(LAMBDA_hat)'/G;
            se_theta      = sqrt(diag(VCOV_theta_hat));                 % Asymptotic std. errors for theta_hat
            t_theta       = theta_hat ./ se_theta;                      % t-stats
            pv_theta      = 2*(1-normcdf(abs(t_theta)));                % p-values (for H0: theta=0)      
        
            gamma_ape     = theta_hat(Q+1:end);
            V_ape         = VCOV_theta_hat(Q+1:end,Q+1:end);
            se_ape        = sqrt(diag(V_ape));                          % Asymptotic std. errors for ape
            t_ape         = gamma_ape ./ se_ape;                        % t-stats
            pv_ape        = 2*(1-normcdf(abs(t_ape)));                  % p-values (for H0: gamma_ape=0)       
        
            
        else
            %-----------------------------------------%
            %- CASE 1 : PI_mat_d matrix is non-empty -%
            %-----------------------------------------%
            
            % add moment identifying mean of PI_mat_d matrix to the model
            PI_mat_mean   = mean(PI_mat_d)';          % LQ x 1 vector of PI_mat_d column means
            theta_hat     = [theta_hat; PI_mat_mean]; % theta is now a Q + L + LQ x 1 vector                  
            
            % estimate variance-covariance matrix
            % NOTE: Include implicit LQ x 1 PI_mat_d moment
            % when computing the covariance matrix
            
            OMEGA_hat = zeros(Q+L+L*Q,Q+L+L*Q);
            LAMBDA_hat = [-Z'*R/G            zeros(Q+L,L*Q)
                          zeros(L*Q,Q+L)    -eye(L*Q)];
          
            PI_resid = PI_mat_d - repmat(PI_mat_mean',N,1); % N x LQ matrix of moment functions for PI_mat_mean 
            
            for g = 1:1:G     
                % upper & lower bounds for the g-th group
                n1_a = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + 1;                 
                n2_a = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + (T+L)*NG(g);   
                
                n1_b = (sum(NG(1:g)) - NG(g)) + 1;                 
                n2_b = (sum(NG(1:g)) - NG(g)) + NG(g);                
    
                U_g = U(n1_a:n2_a); 
                Z_g = Z(n1_a:n2_a,:);
                PI_resid_g = sum(PI_resid(n1_b:n2_b,:));
                
                OMEGA_hat = OMEGA_hat + [Z_g'*U_g; PI_resid_g']*[Z_g'*U_g; PI_resid_g']'/G; 
            end
            clear n1_a n2_a n1_b n2_b U_g Z_g PI_resid_g;
            
            VCOV_theta_hat= inv(LAMBDA_hat)*OMEGA_hat*inv(LAMBDA_hat)'/G;
            se_theta      = sqrt(diag(VCOV_theta_hat));                 % Asymptotic std. errors for theta_hat
            t_theta       = theta_hat ./ se_theta;                      % t-stats
            pv_theta      = 2*(1-normcdf(abs(t_theta)));                % p-values (for H0: theta=0)

            % get average partial effect by weighting stayers and movers effects            
            gamma_ape     = theta_hat(Q+1:Q+L)...
                            + reshape(PI_mat_mean',Q,L)'*theta_hat(1:Q);             
                        
            J_ape         = [reshape(PI_mat_mean',Q,L)' eye(L) kron(eye(L),theta_hat(1:Q)')];      
            V_ape         = J_ape*VCOV_theta_hat*J_ape';
            se_ape        = sqrt(diag(V_ape));                          % Asymptotic std. errors for ape
            t_ape         = gamma_ape ./ se_ape;                        % t-stats
            pv_ape        = 2*(1-normcdf(abs(t_ape)));                  % p-values (for H0: gamma_ape=0)            
            
        end
        
        % compute wald statistics for H0: H*delta
        if J>0    
            wald_E       = (E*theta_hat(1:Q))'*inv(E*VCOV_theta_hat(1:Q,1:Q)*E')*(E*theta_hat(1:Q));
            pv_E         = 1-chi2cdf(wald_E,J);
        end
        
    else
        
        % naive application of Chamberlain (1982, 1992) `no-trimming' estimation approach
        theta_hat = Zn'*Rn \ Zn'*Yn;
    
        U = Yn - Rn*theta_hat;                  %NT x 1 vector of residuals
        LAMBDA_hat = -Zn'*Rn/G;
        OMEGA_hat  = zeros(L,L);
         
        for g = 1:1:G     
            % upper & lower bounds for the g-th group
            n1 = (sum(L*NG(1:g)) - L*NG(g)) + 1;                 
            n2 = (sum(L*NG(1:g)) - L*NG(g)) + L*NG(g);                
    
            U_g = U(n1:n2); 
            Z_g = Zn(n1:n2,:);
    
            OMEGA_hat = OMEGA_hat + Z_g'*U_g*U_g'*Z_g/G;    
        end
        clear n1 n2 U_g Z_g stayers;     
   
        VCOV_theta_hat= inv(LAMBDA_hat)*OMEGA_hat*inv(LAMBDA_hat)'/G;   
        gamma_ape     = theta_hat;
        V_ape         = VCOV_theta_hat;
        se_ape        = sqrt(diag(V_ape));                          % Asymptotic std. errors for ape
        t_ape         = gamma_ape ./ se_ape;                        % t-stats
        pv_ape        = 2*(1-normcdf(abs(t_ape)));                  % p-values (for H0: gamma_ape=0)       
    end
    
    %-----------------------------------------------------------------%
    %- STEP 3 : DISPLAY ESTIMATION RESULTS                           -%
    %-----------------------------------------------------------------%

    if not(silent==1)
        disp('__________________________________________________________________________');
        disp('PANEL DATA CORRELATED RANDOM COEFFICIENT ESTIMATES');
        disp('__________________________________________________________________________');  
        disp(['Dependent variable           : ' Y_name]);   
        disp(['Number of units (N)          : ' int2str(N)]);   
        disp(['Number of periods (T)        : ' int2str(T)]);   
        disp(['Number of clusters (G)       : ' int2str(G)]);   
        disp(['dim(W) = Q                   : ' int2str(Q)]);   
        disp(['dim(X) = P                   : ' int2str(P)]);   
        disp(['Bandwith (h)                 : ' num2str(h)]);   
        disp(['Percent observations trimmed : ' num2str(prc_trim)]);    
        disp(['Std. Dev. of det(X)          : ' num2str(std(D))]);    
        if h>0
            disp('_________________________________________________________________________');
            disp('Coefficient estimates for "time-shifter" variables (DELTA)');
            disp('Variable Name     Coefficient     StdErr      t-Stat      p-value');
            disp('_________________________________________________________________________');
            disp([char(W_names) char(num2str([theta_hat(1:Q) se_theta(1:Q) t_theta(1:Q) pv_theta(1:Q)]))]);    
            disp(' ');
            if J>0 
                disp('Tests of restrictions on delta');   
                disp(char(E_names));   
                disp(['Wald statistics        : ' num2str(wald_E)]);   
                disp(['p-value                : ' num2str(pv_E)]);
                disp(' ');          
            end           
        end
        disp('_________________________________________________________________________');
        disp('Population average coefficient estimates for "policy" variables (GAMMA)');  
        disp('(NOTE: Includes E[PI(X)]*delta component where applicable)');
        disp('Variable Name     Coefficient     StdErr      t-Stat      p-value');
        disp('_________________________________________________________________________');
        disp([char(gamma_names) char(num2str([gamma_ape se_ape t_ape pv_ape]))]);
        disp('_________________________________________________________________________');
        disp('NOTE: "clustered" standard errors using NG group definitions');
        disp(' ');    
    end
else   
    
%-----------------------------------------------------------------------%
%-   OVER IDENTIFIED CASE (T>P): trimmed Chamberlain (1992) estimator  -%
%-   (using identity matrix as a weight matrix)                        -%
%-----------------------------------------------------------------------%

    %-----------------------------------------------------------------%
    %- STEP 1 : DEFINE T + L x Q + L INSTRUMENT VECTOR FOR EACH UNIT -%
    %-----------------------------------------------------------------%

    X = reshape(X',P,N*T);                      % rehape into a P x NT matrix
    W = reshape(W',Q,N*T);                      % rehape into a Q x NT matrix
    PI_mat = reshape(PI_mat',P,N*L);            % rehape into a P x NL matrix  
    Z = zeros((T+L)*N,Q+L);                     % (T+L)*N x Q + L `instrument' matrix
    R = zeros((T+L)*N,Q+L);                     % (T+L)*N x Q + L `regressor' matrix
    Yr= zeros((T+L)*N,1);                       % (T+L)*N x 1 `outcome' matrix
    det_X = zeros(N,1);                         % vector of unit-specific design matrix determinants
   
    for i = 1:N    
        Y_i = Y(i,:)';                          %T x 1 vector of outcomes for the ith unit
        W_i = W(:,((i-1)*T + 1):(i*T))';        %T x Q time shifter regressor matrix for unit i
        X_i = X(:,((i-1)*T + 1):(i*T))';        %T x P policy regressor matrix for unit i
        PI_i = PI_mat(:,((i-1)*L + 1):(i*L))';  %L x P PI_matrix which defines gamma
        iXX_i = inv(X_i'*X_i);                  %inv(X'X) for ith unit (P x P)    
        M_i = eye(T) - X_i*iXX_i*X_i';          %T x T unit-specific residual maker matrix
        det_X(i) = det(X_i'*X_i);               %determinant of X'X matrix of ith unit (scalar)
               
        % ith unit's contribution to instrument and regressor matrix      
        Yr((T+L)*(i-1)+1:(T+L)*i) = [Y_i; PI_i*iXX_i*X_i'*Y_i];
        Z((T+L)*(i-1)+1:(T+L)*i,:) = [(W_i'*M_i)' zeros(T,L); zeros(L,Q) ((det_X(i)>h)*eye(L))];
        R((T+L)*(i-1)+1:(T+L)*i,:) = [W_i zeros(T,L); PI_i*iXX_i*X_i'*W_i eye(L)];       
    end

    clear Y_i W_i X_i PI_i iXX_i M_i;

    prc_trim = 100*mean((det_X<=h));     %percent of observations used to tie down trend terms (i.e., percent `stayers')
    
    %-----------------------------------------------------------------%
    %- STEP 2 : ESTIMATE BY "TSLS"                                   -%
    %-----------------------------------------------------------------%

    theta_hat = Z'*R \ Z'*Yr;
    U = Yr - R*theta_hat;                  %(T+L)*N x 1 vector of residuals

    if isempty(PI_mat_d)==1
        % CASE 1 : PI_mat_d matrix is empty
        % estimate variance-covariance matrix
        OMEGA_hat  = zeros(Q+L,Q+L);
        LAMBDA_hat = -Z'*R/G;        
 
        for g = 1:1:G     
            % upper & lower bounds for the g-th group
            n1 = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + 1;                 
            n2 = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + (T+L)*NG(g);                
        
            U_g = U(n1:n2); 
            Z_g = Z(n1:n2,:);
        
            OMEGA_hat = OMEGA_hat + (Z_g'*U_g)*(Z_g'*U_g)'/G;    
        end
    
        clear n1 n2 U_g Z_g;
      
        VCOV_theta_hat= inv(LAMBDA_hat)*OMEGA_hat*inv(LAMBDA_hat)'/G;
        se_theta      = sqrt(diag(VCOV_theta_hat));                 % Asymptotic std. errors for theta_hat
        t_theta       = theta_hat ./ se_theta;                      % t-stats
        pv_theta      = 2*(1-normcdf(abs(t_theta)));                % p-values (for H0: theta=0)  
        
        gamma_ape     = theta_hat(Q+1:Q+L);
        V_ape         = VCOV_theta_hat(Q+1:Q+L,Q+1:Q+L);
        se_ape        = sqrt(diag(V_ape));                          % Asymptotic std. errors for ape
        t_ape         = gamma_ape ./ se_ape;                        % t-stats
        pv_ape        = 2*(1-normcdf(abs(t_ape)));                  % p-values (for H0: gamma_ape=0)        
    else
        % CASE 2 : PI_mat_d matrix is non-empty
        % add moment identifying mean of PI_mat_d matrix to the model
        PI_mat_mean   = mean(PI_mat_d)';          % LQ x 1 vector of PI_mat_d column means
        theta_hat     = [theta_hat; PI_mat_mean]; % theta is now a Q + L + LQ x 1 vector                  
            
        % estimate variance-covariance matrix
        % NOTE: Include implicit PI_mat_d moment into the
        % mix when computing the covariance matrix
        OMEGA_hat = zeros(Q+L+L*Q,Q+L+L*Q);
        LAMBDA_hat = [-Z'*R/G           zeros(Q+L,L*Q)
                      zeros(L*Q,Q+L)    -eye(L*Q)];
          
        PI_resid = PI_mat_d - repmat(PI_mat_mean',N,1); % N x LQ matrix of moment functions for PI_mat_mean 
        for g = 1:1:G     
            % upper & lower bounds for the g-th group
            n1_a = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + 1;                 
            n2_a = (sum((T+L)*NG(1:g)) - (T+L)*NG(g)) + (T+L)*NG(g);                
        
            n1_b = (sum(NG(1:g)) - NG(g)) + 1;                 
            n2_b = (sum(NG(1:g)) - NG(g)) + NG(g);                                   
            
            U_g = U(n1_a:n2_a); 
            Z_g = Z(n1_a:n2_a,:);
            PI_resid_g = sum(PI_resid(n1_b:n2_b,:));        
          
            OMEGA_hat = OMEGA_hat + [(Z_g'*U_g); PI_resid_g']*[(Z_g'*U_g); PI_resid_g']'/G;    
        end
    
        clear n1_a n2_a n1_b n2_b U_g Z_g PI_resid_g;
      
        VCOV_theta_hat= inv(LAMBDA_hat)*OMEGA_hat*inv(LAMBDA_hat)'/G;
        se_theta      = sqrt(diag(VCOV_theta_hat));                 % Asymptotic std. errors for theta_hat
        t_theta       = theta_hat ./ se_theta;                      % t-stats
        pv_theta      = 2*(1-normcdf(abs(t_theta)));                % p-values (for H0: theta=0)                       
        
        % gamma estimates and standard errors
        gamma_ape     = theta_hat(Q+1:Q+L) + reshape(PI_mat_mean',Q,L)'*theta_hat(1:Q);
        J_ape         = [reshape(PI_mat_mean',Q,L)' eye(L) kron(eye(L),theta_hat(1:Q)')];      
        V_ape         = J_ape*VCOV_theta_hat*J_ape';
        se_ape        = sqrt(diag(V_ape));                          % Asymptotic std. errors for ape
        t_ape         = gamma_ape ./ se_ape;                        % t-stats
        pv_ape        = 2*(1-normcdf(abs(t_ape)));                  % p-values (for H0: gamma_ape=0)                    
    end
    
    % compute wald statistics for H0: H*delta=0
    if J>0    
        wald_E       = (E*theta_hat(1:Q))'*inv(E*VCOV_theta_hat(1:Q,1:Q)*E')*(E*theta_hat(1:Q));
        pv_E         = 1-chi2cdf(wald_E,J);
    end
    
    %-----------------------------------------------------------------%
    %- STEP 3 : DISPLAY ESTIMATION RESULTS                           -%
    %-----------------------------------------------------------------%

    if not(silent==1)
        disp('__________________________________________________________________________');
        disp('PANEL DATA CORRELATED RANDOM COEFFICIENT ESTIMATES');
        disp('__________________________________________________________________________');  
        disp(['Dependent variable           : ' Y_name]);   
        disp(['Number of units (N)          : ' int2str(N)]);   
        disp(['Number of periods (T)        : ' int2str(T)]);   
        disp(['Number of clusters (G)       : ' int2str(G)]);   
        disp(['dim(W) = Q                   : ' int2str(Q)]);   
        disp(['dim(X) = P                   : ' int2str(P)]);   
        disp(['Bandwith (h)                 : ' num2str(h)]);   
        disp(['Percent observations trimmed : ' num2str(prc_trim)]);    
        disp(['Std. Dev. of det(XX)         : ' num2str(std(det_X))]);    
        disp('_________________________________________________________________________');
        disp('Coefficient estimates for "time-shifter" variables (DELTA)');
        disp('Variable Name     Coefficient     StdErr      t-Stat      p-value');
        disp('_________________________________________________________________________');
        disp([char(W_names) char(num2str([theta_hat(1:Q) se_theta(1:Q) t_theta(1:Q) pv_theta(1:Q)]))]);    
        disp(' ');
        if J>0 
            disp('Tests of restrictions on delta');   
            disp(char(E_names));   
            disp(['Wald statistics        : ' num2str(wald_E)]);   
            disp(['p-value                : ' num2str(pv_E)]);
            disp(' ');          
        end
        disp('_________________________________________________________________________');
        disp('Population average coefficient estimates for "policy" variables (gamma)');
        disp('(NOTE: Includes E[PI(X)]*delta component where applicable)');
        disp('Variable Name     Coefficient     StdErr      t-Stat      p-value');
        disp('_________________________________________________________________________');       
        disp([char(gamma_names) char(num2str([gamma_ape se_ape t_ape pv_ape]))]);
        disp('_________________________________________________________________________');
        disp('NOTE: "clustered" standard errors using NG group definitions');
        disp(' ');    
    end
end