%-------------------------------------------------------------------------%
%- Identification and estimation of correlated random                    -%
%- coefficient models for panel data, Bryan Graham & Jim Powell, Spr. 11 -%
%-------------------------------------------------------------------------%

%-------------------------------------------------------------------------%
%- Base MATLAB file for Calorie Demand application                       -%  
%-------------------------------------------------------------------------%

clear;

%-------------------------------------------------------------------------%
% Load RPS 2000 - 2002 Balanced Panel                                    -%
%-------------------------------------------------------------------------%

% change to directory where "RPS_panel.mat" panel dataset is located
cd('C:\Documents and Settings\bsg1\My Documents\BSG_WORK_19W4th\Research\Panel\Panel_APE_11Spring\PanelDataCodeAndData\');
load RPS_panel.mat;    
clearvars RPS X0te X1te X2te Y0i Y0p Y0z Y0tc Y1i Y1p Y1z Y1tc Y2i Y2p Y2z Y2tc;

% display estimation output'
silent = 0;           

% get vector of dependent variable values and "cluster" IDs organized
Y = [Y0 Y1 Y2];

[NG]    = CountGroupMembers(village);
[N T]   = size(Y);

delete('RPS_panel_estimation_output.log');
diary('RPS_panel_estimation_output.log');
diary on;

%-------------------------------------------------------------------------%
%- LINEAR MODEL (OVER-IDENTIFIED CASE: 2000, 2001 & 2002 data)           -%
%-------------------------------------------------------------------------%

% NOTE: For all the models specified below 2001 is always treated as the
% base year (this is also the base year for the price index). And `common
% trend' represents a shift relative to this base year.

% det_XX
det_XX = 3*(X0.^2 + X1.^2 + X2.^2) - (X0 + X1 + X2).^2;
std_det_XX=std(det_XX);
figure;
subplot(2,1,1);
hist(det_XX,80)
g = findobj(gca,'Type','patch');
set(g,'FaceColor','w','EdgeColor','k')
h = prctile(det_XX,[2 4 8 16]);

% organize regressor matrix
X = [ones(N,1) X0 ones(N,1) X1 ones(N,1) X2];

W = [ones(N,1)      X0                  zeros(N,1)     zeros(N,1) ...
     zeros(N,1)     zeros(N,1)          zeros(N,1)     zeros(N,1)...
     zeros(N,1)     zeros(N,1)          ones(N,1)      X2];

G = length(NG);

% set-up joint hypotheses on delta coefficient  
E = eye(4);
E_names     = ['H0 : No Time Effects/Trends'];

% define target estimands using PI_mat and PI_mat_d matrices
PI_mat      =   [ones(N,1)  zeros(N,1) ...
                 zeros(N,1) ones(N,1)  ...
                 zeros(N,1) ones(N,1)  ...
                 zeros(N,1) ones(N,1)];
PI_mat_d    =   [zeros(N,1) zeros(N,1)  zeros(N,1)  zeros(N,1) ...
                 zeros(N,1) ones(N,1)   zeros(N,1)  zeros(N,1) ...
                 zeros(N,1) zeros(N,1)  zeros(N,1)  zeros(N,1) ...
                 zeros(N,1) zeros(N,1)  zeros(N,1)  ones(N,1)];

% define variable names
Y_name      =  'log(Cal)              ';
gamma_names = ['intercept             ';               
               'log(Exp)_00           ';
               'log(Exp)_01           ';
               'log(Exp)_02           '];
W_names     = ['2000_inter            ';
               '2000_log(Exp)         '; 
               '2002_inter            ';
               '2002_log(Exp)         '];
           
% estimate using Chamberlain's (1992) approach and trimmed variant
PanelCRC(Y, X, W, 0, NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(1), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(2), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(3), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 

%-------------------------------------------------------------------------%
% LINEAR MODEL (JUST - IDENTIFIED CASE: 2001 & 2002 data)                -%
%-------------------------------------------------------------------------%

% det_X
det_X = X2 - X1;
subplot(2,1,2);
bw = min(std(det_X),IQR(det_X)/1.34)*N^(-1/3);
[f,xi] = ksdensity(det_X,(-2.5:0.01:2.5)','width',bw);
plot(xi,f,'k-');
line([-0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3) -0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)],[0 1],'LineStyle','-')
line([ 0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)  0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)],[0 1],'LineStyle','-')

h = [prctile(abs(det_X),[2 8 16]) 0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)];

% organize regressor matrix
Y = [Y1 Y2];

X = [ones(N,1) X1 ones(N,1) X2];

W = [zeros(N,1) zeros(N,1)...
     ones(N,1)  X2];

G = length(NG);

% set-up joint hypotheses on delta coefficient
E = eye(2);
E_names = ['H0 : No Time Effects'];

% define target estimands using PI_mat and PI_mat_d matrices
PI_mat      =   [ones(N,1)  zeros(N,1) ...
                 zeros(N,1) ones(N,1)  ...
                 zeros(N,1) ones(N,1)];

PI_mat_d    =   [zeros(N,1)  zeros(N,1) ...
                 zeros(N,1)  zeros(N,1) ...
                 zeros(N,1)  ones(N,1)];

% define variable names
Y_name      =  'log(Cal)              ';
gamma_names = ['intercept             ';               
               'log(Exp)_01           '
               'log(Exp)_02           '];
W_names     = ['2002_inter            '
               '2002_log(Exp)         '];
           
% estimate using Graham and Powell (2009) approach
PanelCRC(Y, X, W, 0, NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(1), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(2), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(3), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(4), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 

%-------------------------------------------------------------------------%
% NONLINEAR MODEL (JUST - IDENTIFIED CASE: 2000, 2001 & 2002 data)       -%
% (NOTE: Only intercept time effects included)                           -% 
%-------------------------------------------------------------------------%

ieX0 = exp(X0).^-1;
ieX1 = exp(X1).^-1;
ieX2 = exp(X2).^-1;

% det_X
det_X = X0 .* (ieX1 - ieX2) + X1 .* (ieX2 - ieX0) + X2 .* (ieX0 - ieX1);
std_det_X=std(det_X);

lu_dec = prctile(det_X,[10 90]);
i = find((det_X>=lu_dec(1)).*(det_X<=lu_dec(2))==1);
figure;
hist(det_X(i),80)
g = findobj(gca,'Type','patch');
set(g,'FaceColor','w','EdgeColor','k')
line([-0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3) -0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)],[0 200],'LineStyle','-')
line([ 0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)  0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)],[0 200],'LineStyle','-')

h = [prctile(abs(det_X),[5 15]) 0.5*min(std(det_X),IQR(det_X)/1.34)*N^(-1/3)];

% organize NONLINEAR MODEL regressor matrix
Y = [Y0 Y1 Y2];

X = [ones(N,1)  X0  ieX0    ones(N,1)   X1  ieX1    ones(N,1) X2 ieX2];

W = [zeros(N,1) zeros(N,1)...
     ones(N,1)  zeros(N,1)...
     zeros(N,1) ones(N,1)];

G = length(NG);

% set-up joint hypotheses on delta coefficient H0: Edelta=0          
E = eye(2);
E_names     = ['H0 : No Time Effects'];

% define target estimands using PI_mat and PI_mat_d matrices
PI_mat   = [ones(N,1)  zeros(N,1) zeros(N,1)...
            zeros(N,1) ones(N,1)  zeros(N,1)...
            zeros(N,1) zeros(N,1) ones(N,1) ...
            zeros(N,1) ones(N,1)  -ieX0 ...
            zeros(N,1) ones(N,1)  -ieX1 ...
            zeros(N,1) ones(N,1)  -ieX2];
PI_mat_d = [];

% define variable names
Y_name      =  'log(Cal)            ';
gamma_names = ['intercept           ';
               'log(Exp)            ';
               '1/Expenditure       ';
               'elasticity_2000     ';
               'elasticity_2001     ';
               'elasticity_2002     '];             
W_names     = ['2001_inter          ';
               '2002_inter          '];

% estimate using Graham and Powell (2009) approach
PanelCRC(Y, X, W, h(1), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(2), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 
PanelCRC(Y, X, W, h(3), NG, Y_name, W_names, gamma_names, PI_mat, PI_mat_d, E, E_names, silent); 

diary off;

load Coffee_Prices_1998_2004;
figure;
plot(Date,IndicatorPrice);
line([2000+(7/12) 2000+(7/12)],[0 150],'LineStyle','-');
line([2001+(9/12) 2001+(9/12)],[0 150],'LineStyle','-');
line([2002+(9/12) 2002+(9/12)],[0 150],'LineStyle','-');
