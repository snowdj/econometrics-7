
function C = adj(A)

% adj  Adjoint matrix (i.e., transpose of the matrix of cofactors).
%
% If A is invertible, then inv(A) = C' / det(A).

[n,n] = size(A);

for i = 1:n
    for j = 1:n
       M = A;
       M(i,:)=[];       %remove ith row and jth column of A
       M(:,j)=[];
       C(i,j)=(-1)^(i+j)*det(M);
    end        
end

C = C';
