function [B,n_contractions, Match, iH, iJac] = TUM_eq(r_0_sv,theta,p,q,tol1,tol2,cs)

% SUMMARY: This function solves for the equilibrium match distribution
%          associated with a given parameter vector and distribution of
%          types. It calls the function TUM_eq_crit().

% INPUTS
    %   r_0_sv  : K + L vector of starting values for, respectively, 
    %             the number of umatched `females' and `males' of each type
    %   theta   : KL vector of surplus parameters, gamma, plus relative
    %             heterogeneity distribution scale parameter, lambda
    %   p, q    : K x 1 and L x 1 vector giving number of `females' &
    %             `males' of each type
    %   tol1    : convergence criterion for equilibrium
    %   tol2    : Tolerance threshold for LogStar function (used by
    %             TUM_eq_crit())
    %   cs      : If cs = 1 calculate comparative static results
    
% OUTPUTS       
    % B               : K + L equilibrium number of unmatched `females' and `males' of each type
    % n_contractions  : Number of contractions needed to find fixed point
    %                   to specified tolerance
    % iH              : K+L x K+L matrix of singlehood elasticies
    % iJac            : K+L x K+L inverse Jacobian matrix 

sol = 0;
n_contractions = 0;


% Fixed point iteration to find number of ummatched of each of the K+L
% types

while sol==0
    [B] = TUM_eq_crit(r_0_sv,theta,p,q,tol2);
    n_contractions = n_contractions + 1;
    if norm(B-r_0_sv,2)<=tol1
        sol = 1;
    else
        r_0_sv = B;
    end
    
end


if cs == 1

    %-------------------------------------------------------%
    %- Solve for interior part of the equilibrium matching -%
    %-------------------------------------------------------%

    K               = length(p);                                % number of `female' types  
    L               = length(q);                                % number of `male' types
    r_k0            = B(1:K);                                   % equilibrium number of unmatched `females' by type
    r_0l            = B(K+1:K+L);                               % equilibrium number of unmatched `males' by type
    gamma           = reshape(theta(1:K*L),L,K)';               % K x L vector of match surplus parameters
    lambda          = theta(K*L+1);           
    
    R = (r_k0.^(1-lambda)) * (r_0l.^lambda)' .* exp(gamma);
    
    Match = [0 r_0l'; [r_k0 R]];

    %-------------------------------------------------------%
    %- Calculate inverse Jacobian                          -%
    %-------------------------------------------------------%

    A_jac   = diag([r_k0 + (1-lambda)*(p-r_k0); r_0l + lambda*(q-r_0l)]);
    B_jac   = [zeros(K,K) lambda*R; (1-lambda)*R' zeros(L,L)];
    C_jac   = diag([p; q]);
    U_jac   = diag(B);
    iU_jac  = diag(B.^-1);
    
    iH      = inv(A_jac+B_jac)*C_jac;
    iJac    = U_jac*iH*iU_jac;
else
    Match     = [];
    iH        = [];
    iJac      = [];
    
end    


end


