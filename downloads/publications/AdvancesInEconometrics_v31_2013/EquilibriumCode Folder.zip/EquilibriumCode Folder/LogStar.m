function [LogStar, DLogStar, DDLogStar] = LogStar(z,e);

LogStar      = log(z.* (z>=e) + (z<e))               + (log(e) - 1.5 + 2*(z ./ e) - 0.5*(z ./ e).^2) .* (z<e); 
DLogStar     = (z .* (z>=e) + (z<e)).^-1 - 1*(z<e);  + (2/e - (z ./ (e^2))) .* (z<e); 
DDLogStar    =-(z .* (z>=e) + (z<e)).^-2 + 1*(z<e)   - (1/e^2) .* (z<e); 
