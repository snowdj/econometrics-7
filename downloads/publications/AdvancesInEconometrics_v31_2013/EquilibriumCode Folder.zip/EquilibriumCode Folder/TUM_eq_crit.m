function [r_0] = TUM_eq_crit(r_0_sv,theta,p,q,tol)
    
    % SUMMARY: This function iterates on the K + L vector of implicit functions, the fixed point
    %          of which defines the equilibrium number of unmatched agents
    %          of each type. This function is called by TUM_eq().
    
    % INPUTS
    %   r_0_sv  : K + L vector of initial unmatcheds for, respectively, each
    %             `female' and `male' type
    %   theta   : KL vector of surplus parameters, gamma, plus relative
    %             heterogeneity distribution scale parameter, lambda
    %   p, q    : K x 1 and L x 1 vector giving number of `females' &
    %             `males' of each type
    %   tol     : Tolerance threshold for LogStar function
    
    % OUTPUTS   
    %   r_0     : K + L update of unmarrieds of each type


K               = length(p);                                % number of `female' types  
L               = length(q);                                % number of `male' types
r_k0_sv         = r_0_sv(1:K);                              % initial number of unmatched `females' by type
r_0l_sv         = r_0_sv(K+1:K+L);                          % initial number of unmatched `males' by type
gamma           = reshape(theta(1:K*L),L,K)';               % K x L vector of match surplus parameters
lambda          = theta(K*L+1);                             % relative heterogeneity distribution scales

% Iterate on K + L vectors of unmatched agents
t1              = LogStar(repmat(r_0l_sv',K,1) ./ repmat(r_k0_sv,1,L),tol);
t2              = exp(gamma + lambda*t1);
t3              = exp(gamma - (1-lambda)*t1);
r_k0            = p ./ (1 + sum(t2,2));
r_0l            = q ./ (1 + sum(t3,1)');
r_0             = [r_k0; r_0l];


end



