%---------------------------------------------------------%
%- This script reproduces Tables 2 and 3 in the paper    -%
%- "Uniqueness, comparative static, and computation..."  -%
%- by Bryan S. Graham, UC - Berkeley                     -%
%- It calls TUM_eq(), TUM_eq_crit() and LogStar()        -%
%---------------------------------------------------------%

cs      = 1;
tol1    = 0.000001;
tol2    = 0.000001;
r_0_sv  = 1/3*ones(4,1);


p = [5/9; 3/9; 1/9];
q = [1];
lambda = 1/2;

theta = [-1/2; -1/2; 0; lambda];

[B,n_contractions, Match, iH, iJac] = TUM_eq(r_0_sv,theta,p,q,tol1,tol2,cs);
Match

[B,n_contractions, Match, iH, iJac] = TUM_eq(r_0_sv,theta,p+ [5/9; 0; 0],q,tol1,tol2,cs);
Match



    
