function [lstar, fder, sder] = LogStar(v,v_star)

% This function returns log(v) -- as well as its first and second
% derivatives -- if v > v_star; otherwise it returns a quadratic function
% of v that is constructed to coincide with log(v) at v = v_star (the first and
% second derivatives also coincide at this point). See the Appendix to Owen
% (2001) for more details.

% Calculate quadratic function's coefficients
c = -1/v_star.^2;
b = 1/v_star - c*v_star;
a = log(v_star) - b*v_star - (1/2)*c*v_star.^2;

% Evaluate function and first two derivatives
lstar = (v>=v_star) .* (log(v)) + (v<v_star) .* (a + b*v + (1/2)*c*v.^2);
fder  = (v>=v_star) .* (v.^-1)  + (v<v_star) .* (b + c*v);
sder  = (v>=v_star) .* (-v.^-2) + (v<v_star) .* (c);


end

