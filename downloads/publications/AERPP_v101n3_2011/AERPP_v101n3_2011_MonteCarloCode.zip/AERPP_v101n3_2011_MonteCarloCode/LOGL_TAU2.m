function [logl_tau2, score_tau2, hess_tau2] = LOGL_TAU2(tau2,nu,y_bar,mu,v_star)

[log_nu_tau2, fder_log_nu_tau2, sder_log_nu_tau2] = LogStar(nu+tau2,v_star);

logl_tau2  = -(-(1/2)*sum(log_nu_tau2)      - (1/2)*sum(((y_bar - mu).^2) ./ (nu + tau2)));
score_tau2 = -(-(1/2)*sum(fder_log_nu_tau2) + (1/2)*sum(((y_bar - mu)     ./ (nu + tau2)).^2));
hess_tau2  = -(-(1/2)*sum(sder_log_nu_tau2) -       sum(((y_bar - mu).^2) ./ ((nu + tau2).^3)));

end

