function [theta_hat, num_empty_cells] = EB_MAR(D,DY,X,r_X,p_X)

% INPUTS
% D             : N x 1 vector of missingnes indicators (D = 1 if Y
%                 observed, zero if missing)
% DY            : DY = Y if D = 1 and zero otherwise (observed outcomes, N x 1)
% X             : N x K matrix of dummy variables; kth element of ith row
%                 equals 1 if X_i = x_k and zero otherwise.
% r_X           : K x J with kth element such that mu_k = r_X_k'*zeta
% p_X           : K x 1 vector of propensity scores

% STEP 1 : Estimate conditional mean and variance of Y for each value of X
% (NOTE: We treat cells with n_k>2, n_k=1 and n_k=0 differently as described in the paper)
[N K]      = size(X);      % compute sample size and number of covariate cells
p_hat      = mean(X)';     % distribution of the regressors (K x 1 vector with
                           % a kth element of Pr(X=x_k), estimate is N_k/N)
i          = find(D==1);   % find indices for complete case units (N x 1)
Xi         = X(i,:);       % complete-observation X dummy matrix 
nk         = sum(Xi)';     % number of complete observations per cell (K x 1)
k0         = (nk==0);      % indicators for cells with zero obs (N x 1)
k1         = (nk==1);      % indicators for cells with one obs (N x 1)
k2         = (nk>1);       % indicators for cells with two or more obs (N x 1)
num_empty_cells = sum(k0); % number of empty cells 

Yi         = DY(i,:);                       % complete-obs Y 
Ym         = kron(Yi,ones(1,K)).*Xi;        % matrix like Xi but with Y values filled in
y_bar      = (sum(Ym)')./(nk+k0) ;          % cell means, with zeros for empty cells, avoid divide by zero (K x 1)
y2_bar     = (sum(Ym.^2)')./(nk+k0) ;       % sum of squared y by cell (K x 1)
sigma2_hat = y2_bar - (y_bar.^2);           % sample variance by cell (K x 1), zeros for nk=0 or 1 

% NOTE: with small cells it might be better to use the unbiased variance
% estimate (i.e., divide by n_k - 1 instead of n_k)

sigma2avg  = mean(sigma2_hat(sigma2_hat > 0));         % average variance among cells with nk > 1
nu_hat     = (sigma2_hat./(nk+k0)) + (sigma2avg.*k1);  % replace 0 var with sigma2avg for nk==1
                                                       % nu_hat still equals zero if nk==0

% STEP 2 : Estimate parametric conditional mean model by weighted least
%          squares (two versions: without p-score and with p-score as in Bang and
%          Robins (2005))

% Model without propensity score
Xv = Xi*r_X;                         % vector with values of covariates for d=1 subsample (N x J)
zeta_hat = (Xv'*Xv) \ (Xv'*Yi);      % OLS in the complete case subsample
mu_hat   = r_X*zeta_hat;             % Fitted values for cell means

% Model with propensity score
Xvdr = [Xv Xi*(p_X.^-1)];            % augment regressor vector with inverse of the propensity score
zeta_aug_hat = (Xvdr'*Xvdr)\ (Xvdr'*Yi); % OLS in the complete case subsample
mu_aug_hat = [r_X p_X.^-1]*zeta_aug_hat; % Fitted values for cell means

% STEP 3 : Estimate "prior precision" by "random effects maximum likelihood"
% (NOTE: Only use subsample of cells for which n_k>1 as encoded by k2 vector defined above)
options_delta = optimset('LargeScale','on','GradObj','on','Hessian','on',...
                         'Display','off','TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',1000,'MaxIter',1000); 
tau2_SV                    = 0; % use zero as a starting value for tau2_SV;

% model without the propensity score
tau2_crit                  = @(x)LOGL_TAU2(x,nu_hat(k2),y_bar(k2),mu_hat(k2),10/N);
[tau2_hat, fval, exitflag] = fminunc(tau2_crit, tau2_SV, options_delta); 
tau2_hat = max(tau2_hat,0);
gamma_hat                  = (nu_hat ./ (nu_hat+tau2_hat)) + k0;  % sets gammahat=1 for empty cells

% model with the propensity score
tau2_crit                      = @(x)LOGL_TAU2(x,nu_hat(k2),y_bar(k2),mu_aug_hat(k2),10/N);
[tau2_aug_hat, fval, exitflag] = fminunc(tau2_crit, tau2_SV, options_delta); 
tau2_aug_hat = max(tau2_aug_hat,0);
gamma_aug_hat                  = (nu_hat ./ (nu_hat+tau2_aug_hat)) + k0; % set gammahat=1 for empty cells  

% STEP 4 : Compute different estimates of theta = E[Y]
% For the postratification estimate we drop empty cells, renormalizing the distribution of X accordingly
p_hat_nonempty = p_hat(~k0)/sum(p_hat(~k0));                                        % distribution of X, dropping empty cells
theta_hat_PS = sum(p_hat_nonempty.*y_bar(~k0));                                     % post-stratification estimate 

theta_hat_PI = sum(p_hat .* mu_hat);                                                % parametric imputation estimate
theta_hat_DR = sum(p_hat .* mu_aug_hat);                                            % Bang and Robins (2005) DR estimator
theta_hat_EB = sum(p_hat .* ((1 - gamma_hat) .* y_bar + gamma_hat .* mu_hat));      % empirical bayes estimate w/o p-score
theta_hat_EB_ps = sum(p_hat .* ((1 - gamma_aug_hat) .* y_bar + gamma_aug_hat .* mu_aug_hat));   % empirical bayes estimate w/ p-score

theta_hat = [theta_hat_PS; theta_hat_PI; theta_hat_DR; theta_hat_EB; theta_hat_EB_ps];

end
