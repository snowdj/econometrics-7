B = 1000; % number of monte carlo draws

J_Values =  [2; 7; 12; 37; 62; 187];
Nk_Values = [600; 200; 120; 40; 24; 8];
NumDesigns = length(J_Values);

MCSummaryResults = [[5 15 25 75 125 375]' zeros(6,20)];

for j = 1:NumDesigns
    
    % Assume that X is integer-valued from -J to +J. With Nk units per cell.
    % The total number of sampled units is therefore fixed to N=Nk*K. The
    % number of X values is K = 2*J+1. This is a stratified sampling
    % scheme.

    J  = J_Values(j);
    K  = 2*J+1;
    Nk = Nk_Values(j);
    p  = ones(K,1)/K;  % discrete uniform distribution for X

    % The asymptotic standard error of an efficient estimate of E[Y] under random sampling
    % will be equal to sqrt(SVB/K*Nk). Set the SVB to 60.

    SVB = 60;

    % The conditional mean of Y given X is linear in X with an intercept of
    % zero. Since X is distributed symmetrically about zero this means that theta =
    % E[Y] = 0. Choose beta so that the variance of the conditional means
    % E[Y|X] is equal to 1/2 of SVB

    beta = sqrt((SVB/2)/sum(p .* ((-J:1:J)').^2));
    mu   = beta*(-J:1:J)';

    % The propensity score function is a step function in X. The two propensity
    % score values are choosen such that the marginal probability of
    % missingness is 0.5

    Q   = 0.5 ;
    ps1 = 0.75;
    ps2 = (Q - ps1*sum(p(1:J)))/(1 - sum(p(1:J)));
    p_X = [ps1*ones(J,1); ps2*ones(J+1,1)];

    % The remaining parameters to be chosen are the conditional variances of Y
    % given X. We assume homoscedasticity. The common conditional variance is
    % chosen to ensure E[sigma2/p(X)]=SVB/2. 

    E_i_p_X = sum(p(1:J))/ps1 + (1 - sum(p(1:J)))/ps2;
    sigma = sqrt((SVB/2)/E_i_p_X);
    
    % NOTE: Since the distribution of X is fixed across samples due to our 
    % stratified sampling scheme the portion of the SVB that arises from 
    % variation in E[Y|X] is not relevant. The standard error of an efficient
    % estimate under our scheme is thus sqrt(0.5*SVB/K*Nk)

    % generate B simulated datasets (note X matrix is fixed across samples)

    D   = zeros(K*Nk,B);
    DY  = zeros(K*Nk,B);
    X   = kron(eye(K),ones(Nk,1));

    for k = 1:K
        Y_k  = random('norm',mu(k)*ones(Nk,B),sigma*ones(Nk,B));
        D_k  = (random('unif',zeros(Nk,B),ones(Nk,B)) <= p_X(k));
        DY_k = D_k .* Y_k;
        D(((k-1)*Nk + 1):k*Nk,:)  = D_k;
        DY(((k-1)*Nk + 1):k*Nk,:) = DY_k;
    end

    % We consider two "prior" models for E[Y|X]. In the first this CEF is
    % correctly assumed to be linear in X, in the second it is incorrectly
    % assumed to be constant in X.

    MC_Results1 = zeros(B,6);
    MC_Results2 = zeros(B,6);
    r_X1 = [ones(K,1) (-J:1:J)'];
    r_X2 = [ones(K,1)];
    
    for b = 1:B
        [theta_hat1, num_empty_cells] = EB_MAR(D(:,b),DY(:,b),X,r_X1,p_X);
        MC_Results1(b,:) = [theta_hat1' num_empty_cells];
        [theta_hat2, num_empty_cells] = EB_MAR(D(:,b),DY(:,b),X,r_X2,p_X);
        MC_Results2(b,:) = [theta_hat2' num_empty_cells];
    end

    disp('DESIGN SUMMARY: K Nk N med(num_empty_cells)');
    disp([K Nk K*Nk median(MC_Results1(:,6))]);
    disp('DESIGN SUMMARY: Q ps1 ps2 sigma2 beta');
    disp([Q ps1 ps2 sigma.^2 beta]); 
    
    disp('Model 1: PS, PI, DR, EB, EBPS')
    mc1 = [mean(MC_Results1(:,1:5)); median(MC_Results1(:,1:5)); std(MC_Results1(:,1:5)); sqrt(mean((MC_Results1(:,1:5)).^2))];
    disp([ ['MEANS&  ';'MEDIANS&';'STD&    ';'RMSE&   '] table(mc1,4)])

    disp(' ')

    disp('Model 2: PS, PI, DR, EB, EBPS')
    mc2 = [mean(MC_Results2(:,1:5)); median(MC_Results2(:,1:5)); std(MC_Results2(:,1:5)); sqrt(mean((MC_Results2(:,1:5)).^2))];
    disp([ ['MEANS&  ';'MEDIANS&';'STD&    ';'RMSE&   '] table(mc2,4)])

    MCSummaryResults(j,2:end) = [mean(MC_Results1(:,1:5)) mean(MC_Results2(:,1:5)) sqrt(mean((MC_Results1(:,1:5)).^2)) sqrt(mean((MC_Results2(:,1:5)).^2))];
    
end

figure;
subplot(2,1,1);
plot(MCSummaryResults(:,1),MCSummaryResults(:,2),'k-',...
     MCSummaryResults(:,1),MCSummaryResults(:,4),'ko--',MCSummaryResults(:,1),MCSummaryResults(:,6),'kx-.');
h = legend('ps','dr','eb-ps',2,'Location','Best');
set(h,'Interpreter','none')
xlabel('K, Number of Cells')
ylabel('Mean Bias')
title('Model for E[Y|X] Correct')

subplot(2,1,2);
plot(MCSummaryResults(:,1),MCSummaryResults(:,12),'k-',...
     MCSummaryResults(:,1),MCSummaryResults(:,14),'ko--',MCSummaryResults(:,1),MCSummaryResults(:,16),'kx-.');
h = legend('ps','dr','eb-ps',2,'Location','Best');
set(h,'Interpreter','none')
xlabel('K, Number of Cells')
ylabel('RMSE')
title('Model for E[Y|X] Correct')

figure;
subplot(2,1,1);
plot(MCSummaryResults(:,1),MCSummaryResults(:,7),'k-',...
     MCSummaryResults(:,1),MCSummaryResults(:,9),'ko--',MCSummaryResults(:,1),MCSummaryResults(:,11),'kx-.');
h = legend('ps','dr','eb-ps',2,'Location','Best');
set(h,'Interpreter','none')
xlabel('K, Number of Cells')
ylabel('Mean Bias')
title('Model for E[Y|X] Incorrect')

subplot(2,1,2);
plot(MCSummaryResults(:,1),MCSummaryResults(:,17),'k-',...
     MCSummaryResults(:,1),MCSummaryResults(:,19),'ko--',MCSummaryResults(:,1),MCSummaryResults(:,21),'kx-.');
h = legend('ps','dr','eb-ps',2,'Location','Best');
set(h,'Interpreter','none')
xlabel('K, Number of Cells')
ylabel('RMSE')
title('Model for E[Y|X] Incorrect')