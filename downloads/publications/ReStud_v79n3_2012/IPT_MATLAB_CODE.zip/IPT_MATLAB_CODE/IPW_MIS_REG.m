function [gamma_IPW, VCOV_gamma_IPW, delta_ML, VCOV_delta_ML, w_IPW] = IPW_MIS_REG(D,DY,X1,X2,h_X,NG,sw)

% This function computes the IPW parameter estimates associated with the
% linear predictor of X2 given X1 and Y (i.e., E*[X2|X1,Y]) with the latter MAR. 
% This corresponds to Example 2 in paper. The estimator is as
% described in, for example, Wooldridge (Journal of Econometrics, 2007).
% The propensity score takes a logit form with an index linear in h_X. The
% propensity score parameter is estimated by conditional maximum
% likelihood.

% INPUTS
% D         : N x 1 vector with ith element equal to 1 if ith unit's Y variable is observed
%             and zero otherwise
% DY        : D*Y, with Y the N x K1 matrix of regressors missing at random
% X1        : N x K2 matrix of always-observed regressors (should include
%             constant) NOTE: K = K1 + K2 = dim(gamma)
% X2        : N x 1 vector of always-observed scalar-valued outcome
% h_X       : h(X) N x M function for propensity score computation (does not include a
%             constant). Note that t(X) = (1,h(X))'.
% NG        : G x 1 vector with gth row equal to the number of units in the gth cluster 
% sw        : N x 1 vector of known sampling weights

% OUTPUTS
% gamma _IPW        : IPW estimate of gamma
% VCOV_gamma _IPW   : estimated large sample covariance of gamma
% delta_ML          : CMLE estimates of propensity score parameter
% VCOV_delta_ML     : estimated large sample covariance of p-score
%                     parameter
% w_IPW             : IPW probability weights / distribution function
%                     estimate (as described in Section 3 of the paper)

% Functions called  : LOGIT(), LOGIT_LOGL()

% ----------------------------------------------------------------------------------- %
% - STEP 1 : ORGANIZE DATA                                                          - %
% ----------------------------------------------------------------------------------- %

N       = length(D);       % Number of units in sample  
G       = length(NG);      % Number of clusters in sample
N1      = sum(D);          % Number of units with Y observed in the sample  
M       = size(h_X,2);     % Dimension of h_X
K       = size([X1 DY],2); % Dimension of coefficient vector
sw      = sw/mean(sw);     % normalize sample weights to have mean one
t_X     = [ones(N,1) h_X];

% ----------------------------------------------------------------------------------- %
% - STEP 2 : ESTIMATE P-SCORE BY MLE                                                - %
% ----------------------------------------------------------------------------------- %

[delta_ML VCOV_delta_ML] = LOGIT(D,h_X,0,sw);          % MLE of p-score coefficients  
p_X                      = (1+exp(-t_X*delta_ML)).^-1; % Fitted p-score values

% ----------------------------------------------------------------------------------- %
% - STEP 3 : COMPUTE IPW ESTIMATES OF GAMMA                                         - %
% ----------------------------------------------------------------------------------- %

w_IPW   =   (sw .* (D ./ p_X))/N;             % inverse probability weights
R       =   [X1 DY];                          % N x K matrix of unweighted regressors
R_wgt   =   repmat(w_IPW,1,K) .* R;           % N x K matrix of weighted regressors         
gamma_IPW = R_wgt'*R \ R_wgt'*X2;             % IPW point estimates of gamma        

% ----------------------------------------------------------------------------------- %
% - STEP 4 : ESTIMATE SAMPLING VARIANCE                                             - %
% ----------------------------------------------------------------------------------- %

% Form Jacobian matrix
Ms = (N/G)*[-(R .* repmat(sw .* (D ./ p_X),1,K))'*R/N     (-(R .* repmat(sw .* D .* exp(-t_X*delta_ML) .* (X2 - R*gamma_IPW),1,K))'*t_X/N); ...
            zeros(1+M,K)                                  (-t_X'*(repmat(sw .* exp(t_X*delta_ML) ./ (1 + exp(t_X*delta_ML)).^2,1,1+M) .* t_X)/N)];

% Calculate variance-covariance of the moment function
m = [R .* repmat(sw .* (D ./ p_X) .* (X2 - R*gamma_IPW),1,K) (repmat(sw .* (D - p_X),1,1+M) .* t_X)]';

% calculate covariance matrix of moment vector taking into account
% any within-group dependence/clustering
OMEGA = zeros(1+M+K,1+M+K);
for g = 1:1:G     
    % upper & lower bounds for the g-th group
    n1 = (sum(NG(1:g)) - NG(g)) + 1;                 
    n2 = (sum(NG(1:g)) - NG(g)) + NG(g);                
    
    m_g = sum(m(:,n1:n2),2); 
    OMEGA = OMEGA + m_g*m_g'/G;    
end

VCOV_gamma_IPW  = inv(Ms'*inv(OMEGA)*Ms);
VCOV_delta_ML   = VCOV_gamma_IPW(K+1:end,K+1:end);
VCOV_gamma_IPW  = VCOV_gamma_IPW(1:K,1:K);
