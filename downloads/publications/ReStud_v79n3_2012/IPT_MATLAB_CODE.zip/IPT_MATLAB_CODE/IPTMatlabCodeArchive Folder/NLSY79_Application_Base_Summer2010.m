%-------------------------------------------------------------------------%
%- This M file and the accompanying Stata files reproduce                -%
%- estimation results presented in the paper "Inverse                    -%
%- Probability Tilting for Moment Condition Models with Missing Data".   -% 
%- These files are provided "as is". I am unable to assist with their    -%
%- interpretation or use. However please do feel free to e-mail me if    -%
%- you find any mistakes at bryan.graham@nyu.edu. This file generates    -%
%- a MATLAB diary file NLSY_Empirical_Example.log.                       -%             
%-------------------------------------------------------------------------%

clear;

%-------------------------------------------------------------------------%
% Load NLSY79 ESTIMATION SAMPLE                                          -%
%-------------------------------------------------------------------------%

% NOTE: Adjust the directory reference below to point to the directory
% where you have placed the NLSY79_Sample.mat replication dataset file and
% the accompanying M files.
cd('C:\Documents and Settings\bsg1\My Documents\BSG_WORK_19W4th\Research\IPT\IPT_Spr11\ResubmissionFiles\ReplicationCode\Empirical_Application\Created_Data');
load NLSY79_Sample.mat;

%-------------------------------------------------------------------------%
% ORGANIZE DATA                                                          -%
%-------------------------------------------------------------------------%

D = nonmissing;
N = length(D);
N1 = sum(D);
NG = CountGroupMembers(HHID_79);
G = length(NG);

% normalize NLSY79 sample weights to have mean one
sw = sample_wgts/mean(sample_wgts);

% vector of moments to balance
h_X = [black                       (yearborn==63)                  (yearborn==64)                          black .* (yearborn==63)         black .* (yearborn==64)...
       AFQTStd                     LogWage                         AFQTStd .* LogWage                      AFQTStd.^2                      LogWage.^2 ...
       black .* AFQTStd            black .* LogWage                black .* AFQTStd .* LogWage             black .* AFQTStd.^2             black .* LogWage.^2 ...
       (yearborn==63) .* AFQTStd   (yearborn==63) .* LogWage       (yearborn==63) .* AFQTStd .* LogWage    (yearborn==63) .* AFQTStd.^2    (yearborn==63) .* LogWage.^2 ...
       (yearborn==64) .* AFQTStd   (yearborn==64) .* LogWage       (yearborn==64) .* AFQTStd .* LogWage    (yearborn==64) .* AFQTStd.^2    (yearborn==64) .* LogWage.^2 ...
      ];   
    
M = size(h_X,2);                       % number of moments to balance
h_X_sw = repmat(sw, 1, M) .* h_X;      % reweight moments by sampling weights

% ------------------------------------------------------------------------%
% MODEL 1: Age, race and early test score                                -%
% ------------------------------------------------------------------------%

% set up regression model
DY  = zeros(N,1);                      % regressor MAR is childhood standardized IQ
i = find(isnan(EarlyIQStd)==0);
DY(i) = EarlyIQStd(i);
X1 = [ones(N,1) yearborn black];       % other regressors in model
X2 = LogWage;                          % outcome variable 

delete('NLSY_Empirical_Example.log');
diary('NLSY_Empirical_Example.log');
diary off;

% ------------------------------------------------------------------------%
% IPT point estimates                                                    -%
% ------------------------------------------------------------------------%

% compute IPT point estimates and standard errors
[gamma_IPT, VCOV_gamma_IPT, delta_IPT, VCOV_delta_IPT, w_IPT] = IPT_MIS_REG(D,DY,X1,X2,h_X,NG,sw);
se_gamma      = sqrt(diag(VCOV_gamma_IPT)/G);                % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_IPT ./ se_gamma;                       % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('IPT Point estimates and standard errors')
disp([gamma_IPT se_gamma t_gamma pv_gamma]);

disp('IPT propensity score estimates and standard errors')
se_delta      = sqrt(diag(VCOV_delta_IPT)/G);                % Asymptotic std. errors for delta_hat
t_delta       = delta_IPT ./ se_delta;                       % t-stats
pv_delta      = 2*(1-normcdf(abs(t_delta)));                 % p-values (for H0: delta=0)      
disp([delta_IPT se_delta t_delta pv_delta]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_IPT(i))                                  % check weights sum to one
prctile(w_IPT(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_IPT .* D, 1, M) .* h_X)' mean(h_X_sw)']); % verify `exact balance'
diary off;

% ------------------------------------------------------------------------%
% IPW point estimates                                                    -%
% ------------------------------------------------------------------------%

% compute IPW point estimates and standard errors
[gamma_IPW, VCOV_gamma_IPW, delta_ML, VCOV_delta_ML, w_IPW] = IPW_MIS_REG(D,DY,X1,X2,h_X,NG,sw);
se_gamma      = sqrt(diag(VCOV_gamma_IPW)/G);                % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_IPW ./ se_gamma;                       % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)    

diary on;
disp('IPW Point estimates and standard errors')
disp([gamma_IPW se_gamma t_gamma pv_gamma]);

disp('CMLE propensity score estimates and standard errors')
se_delta      = sqrt(diag(VCOV_delta_ML)/G);                 % Asymptotic std. errors for delta_hat
t_delta       = delta_ML ./ se_delta;                        % t-stats
pv_delta      = 2*(1-normcdf(abs(t_delta)));                 % p-values (for H0: delta=0)      
disp([delta_ML se_delta t_delta pv_delta]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_IPW(i))                                   % check to see if weights sum to one
prctile(w_IPW(i),[0 10 25 50 75 90 100])        % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_IPW .* D, 1, M) .* h_X)' mean(h_X_sw)']);    % check balance
diary off;

% ------------------------------------------------------------------------%
% COMPARISON OF UNWEIGHTED AND IPT AFQT SCORE DISTRIBUTIONS              -%
% ------------------------------------------------------------------------%

Z_fs  = sortrows([AFQTStd sw],1);
F_fs  = cumsum(Z_fs(:,2))/N; 

Z_cc  = sortrows([AFQTStd(i) sw(i)/sum(sw(i)) w_IPT(i)],1);
F_cc  = cumsum(Z_cc(:,2:3));

plot(F_fs,Z_fs(:,1),'y-',F_cc(:,2),Z_cc(:,1),'k-',F_cc(:,1),Z_cc(:,1),'k:')

% ------------------------------------------------------------------------%
% AIPW-RRZ point estimates                                               -%
% ------------------------------------------------------------------------%

% compute AIPW-RRZ point estimates and standard errors
[gamma_AIPW, VCOV_gamma_AIPW, delta_ML, VCOV_delta_ML, w_AIPW] = AIPW_MIS_REG(D,DY,X1,X2,h_X,NG,sw,4);
se_gamma      = sqrt(diag(VCOV_gamma_AIPW)/G);               % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_AIPW ./ se_gamma;                      % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('AIPW-RRZ Point estimates and standard errors')
disp([gamma_AIPW se_gamma t_gamma pv_gamma]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_AIPW(i))                                  % check weights sum to one
prctile(w_AIPW(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_AIPW .* D, 1, M) .* h_X)' mean(h_X_sw)']); % verify `exact balance'
diary off;

% ------------------------------------------------------------------------%
% AIPW-NEWEY point estimates                                             -%
% ------------------------------------------------------------------------%

% compute AIPW-NEWEY point estimates and standard errors
[gamma_AIPW, VCOV_gamma_AIPW, delta_ML, VCOV_delta_ML, w_AIPW] = AIPW_MIS_REG(D,DY,X1,X2,h_X,NG,sw,1);
se_gamma      = sqrt(diag(VCOV_gamma_AIPW)/G);               % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_AIPW ./ se_gamma;                      % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('AIPW-NEWEY Point estimates and standard errors')
disp([gamma_AIPW se_gamma t_gamma pv_gamma]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_AIPW(i))                                  % check to see if weights sum to one
prctile(w_AIPW(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_AIPW .* D, 1, M) .* h_X)' mean(h_X_sw)']);   % check balance
diary off;

% ------------------------------------------------------------------------%
% AIPW-HIW point estimates                                               -%
% ------------------------------------------------------------------------%

% compute AIPW-HIW point estimates and standard errors
[gamma_AIPW, VCOV_gamma_AIPW, delta_ML, VCOV_delta_ML, w_AIPW] = AIPW_MIS_REG(D,DY,X1,X2,h_X,NG,sw,2);
se_gamma      = sqrt(diag(VCOV_gamma_AIPW)/G);               % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_AIPW ./ se_gamma;                      % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('AIPW-HIW Point estimates and standard errors')
disp([gamma_AIPW se_gamma t_gamma pv_gamma]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_AIPW(i))                                  % check weights sum to one
prctile(w_AIPW(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_AIPW .* D, 1, M) .* h_X)' mean(h_X_sw)']); % verify `exact balance'
diary off;

% ------------------------------------------------------------------------%
% AIPW-CTD point estimates                                               -%
% ------------------------------------------------------------------------%

% compute AIPW-CTD point estimates and standard errors
[gamma_AIPW, VCOV_gamma_AIPW, delta_ML, VCOV_delta_ML, w_AIPW] = AIPW_MIS_REG(D,DY,X1,X2,h_X,NG,sw,3);
se_gamma      = sqrt(diag(VCOV_gamma_AIPW)/G);               % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_AIPW ./ se_gamma;                      % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('AIPW-CTD Point estimates and standard errors')
disp([gamma_AIPW se_gamma t_gamma pv_gamma]);

% inspect the implicit distribution function estimate
i = find(D==1);

disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_AIPW(i))                                  % check weights sum to one
prctile(w_AIPW(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_AIPW .* D, 1, M) .* h_X)' mean(h_X_sw)']); % verify `exact balance'
diary off;

% ------------------------------------------------------------------------%
% - ADDITIONAL MODELS                                                    -%
% ------------------------------------------------------------------------%

% ------------------------------------------------------------------------%
% - LogWage on Age, Black, AFQT and early test score                     -%
% ------------------------------------------------------------------------%

% set up regression model
DY  = zeros(N,1);                               % regressor MAR is early childhood standardized IQ
i = find(isnan(EarlyIQStd)==0);
DY(i) = EarlyIQStd(i);
X1 = [ones(N,1) yearborn black AFQTStd];        % other regressors in model
X2 = LogWage;                                   % outcome variable 

% ------------------------------------------------------------------------%
% IPT point estimates                                                    -%
% ------------------------------------------------------------------------%

% compute IPT point estimates and standard errors
[gamma_IPT, VCOV_gamma_IPT, delta_IPT, VCOV_delta_IPT, w_IPT] = IPT_MIS_REG(D,DY,X1,X2,h_X,NG,sw);
se_gamma      = sqrt(diag(VCOV_gamma_IPT)/G);                % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_IPT ./ se_gamma;                       % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('LogWage on Age, race, AFQT and early test score')
disp('IPT Point estimates and standard errors')
disp([gamma_IPT se_gamma t_gamma pv_gamma]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_IPT(i))                                  % check weights sum to one
prctile(w_IPT(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_IPT .* D, 1, M) .* h_X)' mean(h_X_sw)']); % verify `exact balance'
diary off;

% ------------------------------------------------------------------------%
% - AFQT on Age, race, and early test score                              -%
% ------------------------------------------------------------------------%

X1 = [ones(N,1) yearborn black];                 % other regressors in model
X2 = AFQTStd;                                    % outcome variable 

% ------------------------------------------------------------------------%
% IPT point estimates                                                    -%
% ------------------------------------------------------------------------%

% compute IPT point estimates and standard errors
[gamma_IPT, VCOV_gamma_IPT, delta_IPT, VCOV_delta_IPT, w_IPT] = IPT_MIS_REG(D,DY,X1,X2,h_X,NG,sw);
se_gamma      = sqrt(diag(VCOV_gamma_IPT)/G);                % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_IPT ./ se_gamma;                       % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('AFQT on Age, race, and early test score')
disp('IPT Point estimates and standard errors')
disp([gamma_IPT se_gamma t_gamma pv_gamma]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_IPT(i))                                  % check weights sum to one
prctile(w_IPT(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp([sum(repmat(w_IPT .* D, 1, M) .* h_X)' mean(h_X_sw)']); % verify `exact balance'
diary off;

