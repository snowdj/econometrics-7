function [phi, phi1, phi2] = IPT_LOGIT_PHI(delta, t_X, N)

% This function evaluates the modified phi(v) function for the logit case
% as described in Graham, Pinto and Egel (2010) as well as its first and 
% second derivatives at a vector of values for t(X)'delta.

% Coefficients on quadratic extrapolation of phi(v) 
c = -(N - 1);
b = N + (N - 1)*log(1/(N - 1));
a = -(N - 1)*(1 + log(1/(N - 1)) + 0.5*(log(1/(N - 1)))^2); 
v_star = log(1/(N - 1)); 

% Evaluation of phi(v) and derivatives
v          =  t_X*delta;
phi        =  (v>v_star) .* (v - exp(-v))   + (v<=v_star) .* (a + b*v + 0.5*c*v.^2);
phi1       =  (v>v_star) .* (1 + exp(-v))   + (v<=v_star) .* (b + c*v);
phi2       =  (v>v_star) .* (- exp(-v))     + (v<=v_star) .* c;


