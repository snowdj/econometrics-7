function [CRIT, FOC, SOC] = IPT_LOGIT_CRIT(delta,D,t_X,M,N,sw)

% This function evaluates the IPT logit criterion function as well as its
% first and second derivatives. It uses the modification of the criterion
% function described in the Appendix of Graham, Pinto and Egel (2010). This
% function is called by IPT_LOGIT(). Variable definitions are as described
% in that function.

[phi, phi1, phi2] = IPT_LOGIT_PHI(delta, t_X, N);    % compute phi and 1st/2nd derivatives

CRIT    = -sum(sw.* (D .* phi - t_X*delta));           % IPT criterion
FOC     = -t_X'*(sw.* (D .* phi1 - 1));                % gradient
SOC     = ((repmat(sw .* phi2,1,1 + M) .* t_X)'*t_X);  % hessian