function [gamma_IPT, VCOV_gamma_IPT, delta_IPT, VCOV_delta_IPT, w_IPT] = IPT_MIS_REG(D,DY,X1,X2,h_X,NG,sw)

% This function computes the IPT parameter estimates associated with the
% linear predictor of X2 given X1 and Y with the latter MAR. This 
% corresponds to Example 2 in the "Inverse Probability Tilting"
% paper of Graham, Pinto and Egel (2010).

% INPUTS
% D     : N x 1 vector with ith element equal to 1 if ith unit's Y variable is observed
%         and zero otherwise
% DY    : D*Y, with Y the N x K1 matrix of regressors missing at random
% X1    : N x K2 matrix of always-observed regressors (should include
%         constant) NOTE: K = K1 + K2 = dim(gamma)
% X2    : N x 1 vector of always-observed scalar-valued outcome
% h_X   : h(X) N x M function for IPT computation (does not include a
%         constant)
% NG    : G x 1 vector with gth row equal to the number of units in the gth cluster 
% sw    : N x 1 vector of known sampling weights

% OUTPUTS
% gamma _IPT        : IPT estimate of gamma
% VCOV_gamma _IPT   : estimated large sample covariance of gamma
% delta_IPT         : IPT estimates of propensity score parameter
% VCOV_delta_IPT    : estimated large sample covariance of p-score
%                     parameter
% w_IPT             : IPT probability weights / distribution function
%                     estimate

% ----------------------------------------------------------------------------------- %
% - STEP 1 : ORGANIZE DATA                                                          - %
% ----------------------------------------------------------------------------------- %

N       = length(D);       % Number of units in sample  
G       = length(NG);      % Number of clusters in sample
N1      = sum(D);          % Number of units with Y observed in the sample  
M       = size(h_X,2);     % Dimension of h_X
K       = size([X1 DY],2); % Dimension of coefficient vector
sw      = sw/mean(sw);     % normalize sample weights to have mean one
t_X     = [ones(N,1) h_X];

% ----------------------------------------------------------------------------------- %
% - STEP 2 : ESTIMATE P-SCORE BY IPT                                                - %
% ----------------------------------------------------------------------------------- %

[delta_IPT VCOV_delta_IPT HESS_IPT] = IPT_LOGIT(D,h_X,0,sw);       % IPT estimates of p-score coefficients  
p_X                                 = (1+exp(-t_X*delta_IPT)).^-1; % Fitted p-score values

% ----------------------------------------------------------------------------------- %
% - STEP 3 : COMPUTE IPT ESTIMATES OF GAMMA                                         - %
% ----------------------------------------------------------------------------------- %

w_IPT   =   (sw .* (D ./ p_X))/N;             % inverse probability tilting weights
R       =   [X1 DY];                          % N x K matrix of unweighted regressors
R_wgt   =   repmat(w_IPT,1,K) .* R;           % N x K matrix of weighted regressors         
gamma_IPT = R_wgt'*R \ R_wgt'*X2;             % IPT point estimates of gamma        

% ----------------------------------------------------------------------------------- %
% - STEP 4 : ESTIMATE SAMPLING VARIANCE                                             - %
% ----------------------------------------------------------------------------------- %

% Form Jacobian matrix
Ms = (N/G)*[-(R .* repmat(sw .* (D ./ p_X),1,K))'*R/N     (-(R .* repmat(sw .* D .* exp(-t_X*delta_IPT) .* (X2 - R*gamma_IPT),1,K))'*t_X/N); ...
            zeros(1+M,K)                                  (-HESS_IPT/N)];

% Calculate variance-covariance of the moment function
m = [R .* repmat(sw .* (D ./ p_X) .* (X2 - R*gamma_IPT),1,K) (repmat(sw .* (D ./ p_X - 1),1,1+M) .* t_X)]';

% calculate covariance matrix of moment vector taking into account
% any within-group dependence/clustering
OMEGA = zeros(1+M+K,1+M+K);
for g = 1:1:G     
    % upper & lower bounds for the g-th group
    n1 = (sum(NG(1:g)) - NG(g)) + 1;                 
    n2 = (sum(NG(1:g)) - NG(g)) + NG(g);                
    
    m_g = sum(m(:,n1:n2),2); 
    OMEGA = OMEGA + m_g*m_g'/G;    
end

VCOV_gamma_IPT  = inv(Ms)*OMEGA*inv(Ms)';
VCOV_gamma_IPT  = VCOV_gamma_IPT(1:K,1:K);




