function [gamma_hat, se_gamma_hat] = ParametricImputation(D,DY,X)

% This function computes the mean of Y (i.e., gamma = E[Y]) when Y is
% missing at random. It does so via parametric (linear) imputation as in Rubin
% (1977). 

% INPUTS
% D     : N x 1 vector with ith element equal to 1 if ith unit's Y is observed
%         and zero otherwise
% DY    : D*Y, with Y the N x 1 vector of outcomes
% X     : X, N x M matrix of covariates (must include a constant)

% ----------------------------------------------------------------------------------- %
% - STEP 1 : ORGANIZE DATA                                                          - %
% ----------------------------------------------------------------------------------- %

N       = length(D);      % Number of units in sample  
N1      = sum(D);         % Number of units with Y observed in the sample  
M       = size(X,2);      % Dimension of X

% ----------------------------------------------------------------------------------- %
% - STEP 2 : ESTIMATE GAMMA                                                         - %
% ----------------------------------------------------------------------------------- %

DX = repmat(D,1,M) .* X;
PI_star_hat = DX'*DX \ DX'*DY;
gamma_hat   = mean(X*PI_star_hat);

% ----------------------------------------------------------------------------------- %
% - STEP 3 : CALCULATE STANDARD ERRORS                                              - %
% ----------------------------------------------------------------------------------- %

% covariance matrix of moments
m1 = [X'.* repmat((DY - DX*PI_star_hat),1,M)'];                             % 1+M x N matrix of m_1 moments
m2 = (X*PI_star_hat - gamma_hat)';                                          % 1 x N matrix of m_2 moments
m  = [m1; m2];                                                              % 1+M+1 x N matrix of moments    
V_m = m*m'/N;                                                                                       

% inverse of jacobian matrix
M1PI    = (DX'*DX)/N;
M2PI    = mean(X);
iM      = [inv(M1PI) zeros(M,1); M2PI*inv(M1PI) -1];

% estimated asymptotic standard error for gamma_hat
se_gamma_hat = sqrt(iM*V_m*iM'/N);
se_gamma_hat = se_gamma_hat(end,end);