rand('state',2008);
randn('state',2008);

B           = 50;
N           = 1000;

for design = 1:4,
	MC_Results_PI  = zeros(B,2);

	for b = 1:B
		[D, DY, X] = Test_DGP(design,N);
	    [gamma_PI se_gamma_PI] = ParametricImputation(D,DY,X);
	    MC_Results_PI(b,:) = [gamma_PI se_gamma_PI];
	end
	
% Results for Design 1
disp('RESULTS FOR DESIGN ')
disp('A: Parametric (Linear) Imputation (PI)')
disp('bias_MC se_MC sd_MC');
disp([median(MC_Results_PI) std(MC_Results_PI(:,1))]);

end

