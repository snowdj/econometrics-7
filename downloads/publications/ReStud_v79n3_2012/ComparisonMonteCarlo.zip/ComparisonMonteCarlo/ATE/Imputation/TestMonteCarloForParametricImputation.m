rand('state',2008);
randn('state',2008);

B           = 500;
N           = 1000;

% Design 1
sigma_u     = 1/8;
alpha0      = 0;
alpha1      = -0.25;
alpha2      = 0;
a           = 0.5;
b           = 0.2;
beta0       = 0;
beta1       = 2.19722;
beta2       = 0;
c           = 0.15;


MC_Results_PI  = zeros(B,2);

for b = 1:B
    U = random('normal',zeros(N,1), sigma_u*ones(N,1));
    X = random('unif',-ones(N,1), ones(N,1));
    Y = alpha0 + alpha1*X + alpha2*normcdf((X-a)/b,zeros(N,1),ones(N,1)) + U;
    p_X = (1+exp(-beta0 - beta1*X - beta2*normcdf(X/c))).^-1;      
    D = (random('unif',zeros(N,1),ones(N,1)) <= p_X);
    DY = D .* Y;
    X = [ones(N,1) X];
    [gamma_PI se_gamma_PI] = ParametricImputation(D,DY,X);
    MC_Results_PI(b,:) = [gamma_PI se_gamma_PI];
end

% Results for Design 1
disp('RESULTS FOR DESIGN 1')
disp('A: Parametric (Linear) Imputation (PI)')
disp('bias_MC se_MC sd_MC');
disp([median(MC_Results_PI) std(MC_Results_PI(:,1))]);

% Design 2
sigma_u     = 1/8;
alpha0      = -0.1251;
alpha1      = -0.25;
alpha2      = 0.50;
a           = 0.5;
b           = 0.2;
beta0       = 0;
beta1       = 2.19722;
beta2       = 0;
c           = 0.15;


MC_Results_PI  = zeros(B,2);

for b = 1:B
    U = random('normal',zeros(N,1), sigma_u*ones(N,1));
    X = random('unif',-ones(N,1), ones(N,1));
    Y = alpha0 + alpha1*X + alpha2*normcdf((X-a)/b,zeros(N,1),ones(N,1)) + U;
    p_X = (1+exp(-beta0 - beta1*X - beta2*normcdf(X/c))).^-1;      
    D = (random('unif',zeros(N,1),ones(N,1)) <= p_X);
    DY = D .* Y;
    X = [ones(N,1) X];
    [gamma_PI se_gamma_PI] = ParametricImputation(D,DY,X);
    MC_Results_PI(b,:) = [gamma_PI se_gamma_PI];
end

% Results for Design 2
disp('RESULTS FOR DESIGN 2')
disp('A: Parametric (Linear) Imputation (PI)')
disp('bias_MC se_MC sd_MC');
disp([median(MC_Results_PI) std(MC_Results_PI(:,1))]);

% Design 3
sigma_u     = 1/8;
alpha0      = 0;
alpha1      = -0.25;
alpha2      = 0;
a           = 0.5;
b           = 0.2;
beta0       = 2;
beta1       = 4.19722;
beta2       = -4;
c           = 0.15;


MC_Results_PI  = zeros(B,2);

for b = 1:B
    U = random('normal',zeros(N,1), sigma_u*ones(N,1));
    X = random('unif',-ones(N,1), ones(N,1));
    Y = alpha0 + alpha1*X + alpha2*normcdf((X-a)/b,zeros(N,1),ones(N,1)) + U;
    p_X = (1+exp(-beta0 - beta1*X - beta2*normcdf(X/c))).^-1;      
    D = (random('unif',zeros(N,1),ones(N,1)) <= p_X);
    DY = D .* Y;
    X = [ones(N,1) X];
    [gamma_PI se_gamma_PI] = ParametricImputation(D,DY,X);
    MC_Results_PI(b,:) = [gamma_PI se_gamma_PI];
end

% Results for Design 3
disp('RESULTS FOR DESIGN 3')
disp('A: Parametric (Linear) Imputation (PI)')
disp('bias_MC se_MC sd_MC');
disp([median(MC_Results_PI) std(MC_Results_PI(:,1))]);

% Design 4
sigma_u     = 1/8;
alpha0      = -0.12510;
alpha1      = -0.25;
alpha2      = 0.5;
a           = 0.5;
b           = 0.2;
beta0       = 2;
beta1       = 4.19722;
beta2       = -4;
c           = 0.15;


MC_Results_PI  = zeros(B,2);

for b = 1:B
    U = random('normal',zeros(N,1), sigma_u*ones(N,1));
    X = random('unif',-ones(N,1), ones(N,1));
    Y = alpha0 + alpha1*X + alpha2*normcdf((X-a)/b,zeros(N,1),ones(N,1)) + U;
    p_X = (1+exp(-beta0 - beta1*X - beta2*normcdf(X/c))).^-1;      
    D = (random('unif',zeros(N,1),ones(N,1)) <= p_X);
    DY = D .* Y;
    X = [ones(N,1) X];
    [gamma_PI se_gamma_PI] = ParametricImputation(D,DY,X);
    MC_Results_PI(b,:) = [gamma_PI se_gamma_PI];
end

% Results for Design 4
disp('RESULTS FOR DESIGN 4')
disp('A: Parametric (Linear) Imputation (PI)')
disp('bias_MC se_MC sd_MC');
disp([median(MC_Results_PI) std(MC_Results_PI(:,1))]);