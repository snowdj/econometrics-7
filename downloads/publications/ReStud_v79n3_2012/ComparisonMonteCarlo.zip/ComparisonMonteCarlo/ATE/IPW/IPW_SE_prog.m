% IPW program (3/3) - see IPW.m for more details
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code


function [IPW_SE] = IPW_SE_prog(alpha, gamma, Y, X, D, N)

% I calculate the variance in two ways:
% 1) The first is the asymptotic variance presented in the note [this is not reported as output]
% 2) The second is the sampling variance from Wooldridge (2002).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate some preliminary values: %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	p_hat = exp(X*alpha)./(1+exp(X*alpha));

	% dp_dalpha is the first derivative of p_hat
	% - It is of size N X dimension(alpha):
	
	size_alpha = size(alpha,1);
	dp_dalpha = X.*repmat(exp(X*alpha)./(1+exp(X*alpha)).^2, [1 size_alpha]);

	% dp_dalpha2 is the second derivative of p_hat
	% - It is of size N X dimension(alpha) X dimesion(alpha):

	dp_dalpha2 = repmat(reshape(X, [N size_alpha 1]), [1 1 size_alpha]).*repmat(reshape(X, [N 1 size_alpha ]), [1 size_alpha 1]);
	dp_dalpha2 = dp_dalpha2.*repmat(exp(X*alpha).*(1-exp(X*alpha))./(1+exp(X*alpha)).^3, [1 size_alpha size_alpha]);

	% logf_1 is the first derivative of log[f(D|alpha,X)]:
	
	logf_1 = dp_dalpha.*repmat((D - p_hat)./((1-p_hat).*p_hat), [1 size_alpha]);

	% logf_2 is the second derivative of log[f(D|alpha,X)]:

	logf_2 = dp_dalpha2.*repmat((D - p_hat)./((1-p_hat).*p_hat), [1 size_alpha size_alpha]);
	logf_22 = repmat(reshape(dp_dalpha, [N size_alpha 1]), [1 1 size_alpha]).*repmat(reshape(dp_dalpha, [N 1 size_alpha]), [1 size_alpha 1]);
	logf_2 = logf_2 - logf_22.*repmat((p_hat.^2 + D.*(1-2*p_hat))./((1-p_hat).^2.*p_hat.^2), [1 size_alpha size_alpha]);

%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the Lambda: %
%%%%%%%%%%%%%%%%%%%%%%%%%

	% Start with the second half:
	
	Lambda = dp_dalpha.*repmat(D./p_hat.^2.*(Y-gamma), [1 size_alpha]);
	Lambda = mean(Lambda,1)*inv(reshape(mean(logf_2,1), [size_alpha size_alpha]));
	Lambda = repmat(Lambda, [N 1]).*logf_1;
	Lambda = sum(Lambda,2);
	Lambda = Lambda + D.*(Y - gamma)./p_hat;
	Lambda_Lambda = mean(Lambda.^2,1);
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the variance and SE: %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	outer = mean(D./p_hat);
	var = inv(outer)*Lambda_Lambda*inv(outer)';
	IPW_SE = (var/N)^.5;

%%%%%%%%%%%%%%%%%%%%%%%%%
%% Wooldridge Variance: %
%%%%%%%%%%%%%%%%%%%%%%%%%

	K = -2*(Y - gamma).*D./p_hat;
	L = dp_dalpha.*repmat(D./p_hat, [1 size_alpha]) - dp_dalpha.*repmat((1-D)./(1-p_hat), [1 size_alpha]);
	A = mean(2*D./p_hat);
	B = K'*K/N - K'*L*pinv(L'*L)*L'*K/N;
	var = pinv(A)*B*pinv(A);
	IPW_SE = (var/N)^.5;
