% Implements the IPW estimator of Wooldridge as described in the technical appendix 
% -> This is the first of three programs for IPW (1/3)
% -> Calls two functions:
%		1) Objective function for IPW (IPW_fun.m) (2/3)
%		2) Function that calcluates the variance for IPW (IPW_SE_prog.m) (3/3)
%
% -> Note that this uses the logit function of James P. LeSage
%		- Available at http://www.spatial-econometrics.com/
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [gamma_IPW, IPW_SE] = IPW(D, Y, X) 

%%%%%%%%%%%%%%%
% First stage %
%%%%%%%%%%%%%%%

	cd Tools

	N = size(D,1);
	X = [ones(N,1),X];

	alpha = logit(D,X);
	alpha_logit = alpha.beta;

	cd ..

%%%%%%%%%%%%%%%%
% Second stage %
%%%%%%%%%%%%%%%%

	gamma = mean(Y);

    options = optimset('LargeScale', 'off', 'GradObj','off','Hessian','off',...
                             'Display','off','DerivativeCheck','off',...
                             'Diagnostics','off','TolFun',1e-5,'TolX', 1e-5,...
                             'MaxFunEvals',1000, 'MaxIter', 1000);

	[gamma_IPW] = fminunc('IPW_fun', gamma, options, Y, X, D, alpha_logit);

	[IPW_SE] = IPW_SE_prog(alpha_logit, gamma_IPW, Y, X, D, N);

