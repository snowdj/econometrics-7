% IPW program (2/3) - see IPW.m for more details
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [gamma_IPW] = IPW(gamma, Y, X, D, alpha_logit) 

	psi_Z_gamma = (Y - gamma).^2;
	p_hat = exp(X*alpha_logit)./(1+exp(X*alpha_logit));
	gamma_IPW = psi_Z_gamma.*D./p_hat;
	gamma_IPW = mean(gamma_IPW);
