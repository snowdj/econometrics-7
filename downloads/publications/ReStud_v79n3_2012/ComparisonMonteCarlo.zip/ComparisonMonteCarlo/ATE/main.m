% Implements Monte Carlo experiment in Section 6.1 of Egel, Graham and Pinto (2008)
% See the technical appendix available at www.egels.org/Daniel/Research for more details on these
% estimators
%  
% -> Results produced by this file correspond to the results reported in Tables 2-5 of EGP
%
% Programs called by this program:
%	1) DGP = the data generating process for the Monte Carlo
%	2) IPW (see technical appendix for details)
%	3) IPT (see EGP [2008] for details)
%	4) INR (see technical appendix for details)
%	5) CHT (see technical appendix for details)
%	6) AIPW (see technical appendix for details)
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

clear all

rand('state',2008);
randn('state',2008);

format short
time = clock;
starttime = time(:,4:6)
format long

for j=1:4,

N = 1000;
design = j;
M = 5000;

point = zeros(M,10);
SEs = zeros(M,10);
AIPW_SE_simple = zeros(M,1);


for i = 1: M;
	cd DGP
		[DY, D, X, oracle, TWE] = DGP(N, design);
	cd ..

	point(i,1:2) = [oracle(1,1), TWE(1,1)];
	SEs(i,1:2) = [oracle(1,2), TWE(1,2)];

	X_2=[X,X.^2];

	cd IPW
		[point(i,3), SEs(i,3)] = IPW(D, DY, X);
		[point(i,4), SEs(i,4)] = IPW(D, DY, X_2);
	cd ..

	cd IPT
		[point(i,5), SEs(i,5), ILT_fail(i,1)]=IPT(D, DY, X);
	cd ..

    cd INR
		[point(i,6), SEs(i,6), k_INR(i)] = INR(D, DY, X);
	cd ..

    cd CHT
		[point(i,7), SEs(i,7)]=CHT(D, DY, X);
		[point(i,8), SEs(i,8)]=CHT(D, DY, X_2);
	cd ..  

	cd Imputation
	    [point(i,9), SEs(i,9)] = ParametricImputation(D,DY,[ones(N,1),X]);
	cd ..
	
	cd AIPW
		[point(i,10), SEs(i,10), AIPW_SE_simple(i,1)] = AIPW(DY, X, D);
	cd ..
end

point = [point, point(:,10)];
SEs = [SEs, AIPW_SE_simple];

design
'Order of results:'	
'Oracle			  True Weights		IPW		    HIR		      IPT		   	INR		CHT		    AIPW	AIPW (non-GMM variance)'
median_bias = median(point(:,:),1)
median_SE = median(SEs(:,:),1)
SD = var(point(:,:),1).^.5

confidence95 = (point(:,:)<0).*(point(:,:) + 1.96*SEs(:,:) > 0) + (point(:,:) > 0).*(point(:,:) - 1.96*SEs(:,:) < 0);
confidence95 = mean(confidence95)

'Number of terms used by INR:'
median_K_INR = median(k_INR)
mean_K_INR = mean(k_INR)

end

format short
starttime
time = clock;
endtime = time(:,4:6)
