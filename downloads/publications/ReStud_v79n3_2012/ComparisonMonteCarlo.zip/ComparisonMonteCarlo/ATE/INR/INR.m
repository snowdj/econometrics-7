% Implements the INR estimator as described in the technical appendix 
% -> We also have a version that uses the normalization proposed by INR, the results are the
%	 same and this version is easier to use
%
% -> Note that this uses the logit function of James P. LeSage
%		- Available at http://www.spatial-econometrics.com/
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [theta_INR, INR_SE, k_final] = INR(D, Y, X)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This uses a simplifed version of the INR			%
% - The normalized version is in the INR_normalized %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Different variables are as follows:
% - D is a dummy with 1 = treated, 0 = not
% - Y is the dependent variable
% - X is X

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sort the data so that treated/untreated are grouped: %
% - Select the treated/control groups				   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	N = size(D,1);
	N_1 = sum(D);
	N_0 = N - N_1;

	data = [D, Y, X];
	data = sortrows(data,1);
	D = data(:,1);
	Y = data(:,2);
	X = data(:, 3: 3 + size(X,2) - 1);

k = 0;
endloop = 0;
while endloop == 0,
	k = k + 1;
	
	for i=1:k,
		if i==1,
			P_K=ones(N,1);
		else,
			P_K=[P_K , X.^(i-1)];
		end,
	end

	Y_1 = Y(N_0+1:N,:);
	P_K_1 = P_K(N_0+1:N,:);

	Omega = P_K_1'*P_K_1;
	eigenvals = eig(Omega);
	mineig = min(eigenvals);

	if mineig > 0.5,
		first_stage = pinv(P_K_1'*P_K_1)*P_K_1'*Y_1;
		theta_INR = mean(P_K*first_stage);

		%%%%%%%%%%%%%%%%%%%%%%
		% Calculate variance %
		%%%%%%%%%%%%%%%%%%%%%%

		% First I need to calculate the propensity score:
	
			% Here I use the canned logit optimization routine available from:
			% - James P. LeSage
			% - Econometrics toolbox
			% - Available at http://www.spatial-econometrics.com/
	
			% The HIR approach allows use of 2 elements for N = 1000:
				
				cd Tools
	
				X_HIR = [ones(N,1),X];
			
				gamma = logit(D,X_HIR);
				gamma_logit = gamma.beta;
		
				cd ..
	
			% And now I calculate the propensity score for each observation:
			
			    e_hat = exp(X_HIR*gamma_logit)./(1 + exp(X_HIR*gamma_logit));
	
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
		% This is the variance of the estimator: %
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	
			E_Y1_X = P_K*pinv(P_K_1'*P_K_1)*P_K'*Y;
			V_hat = mean(E_Y1_X.^2);
			V_hat = V_hat + mean(D./(e_hat.^2).*(Y - E_Y1_X).^2);
			MSE_vec(k,1) = V_hat;
	
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	
		% And this this is the MSE: %
		%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
			% Now I need to calculate the sigma^2 term:
			% - This is the variance of the residual from the first stage regression:
		
			u_1 = Y_1 - P_K_1*pinv(P_K_1'*P_K_1)*P_K_1'*Y_1;
			sigma_2 = var(u_1);
	
			a_N1 = 1./e_hat;
			a_N1 = a_N1(N_0 + 1:N,:);
			
			M_KN1 = P_K_1*pinv(P_K_1'*P_K_1)*P_K_1';
			
			first_term = sigma_2*a_N1'*M_KN1*a_N1;
			second_term = (a_N1'*u_1)^2;
			third_term = sigma_2*a_N1'*(eye(N_1) - M_KN1)*a_N1;
	
			MSE = (first_term + second_term - third_term)/N;

		if MSE < 0,
 			% This terminates the program if for some reason the MSE falls below zero
 			% "Blah" is Daniel's favorite termination command if an error occurs.
 			blah
		end

		% Here is where I store all the results for this value of K:
		results(k,:) = [MSE, V_hat, theta_INR, k];

	% The following is the min(eigenvalue) criteria continued:
	else,
		endloop = 1;
	end
end

% Now I sort the results and choose the one with the lowest MSE

results=sortrows(results,1);
theta_INR = results(1,3);
V_hat = results(1,2);
k_final = results(1,4);

INR_SE = (V_hat/N)^0.5;
