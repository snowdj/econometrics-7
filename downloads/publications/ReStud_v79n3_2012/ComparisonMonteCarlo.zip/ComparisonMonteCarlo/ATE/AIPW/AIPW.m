% Implements the AIPW estimator as described in the technical appendix 
% -> This is the first of three programs for AIPW (1/3)
% -> Calls two functions:
%		1) Objective function for AIPW (AIPW_fun.m) (2/3)
%		2) Function that calcluates the variance for AIPW (AIPW_SE_prog.m) (3/3)
% -> Note that this uses the logit function of James P. LeSage
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [gamma_AIPW, AIPW_SE, AIPW_SE_simple] = AIPW(Y, X, D) 

%%%%%%%%%%
% Step 1 %
%%%%%%%%%%

	cd Tools
	
	N = size(D,1);
	X = [ones(N,1),X];
	
	results = logit(D,X);
	alpha = results.beta;

	cd ..

%%%%%%%%%%
% Step 2 %
%%%%%%%%%%

	data = sortrows([D, Y, X],1);
	N_1 = N - sum(D) + 1;
	data = data(N_1:N,:);
	X_1 = data(:,3:4);
	Y_1 = data(:,2);
	beta = inv(X_1'*X_1)*X_1'*Y_1;
	m = X*inv(X_1'*X_1)*X_1'*Y_1;
	
%%%%%%%%%%
% Step 3 %
%%%%%%%%%%

	start = mean(Y);

    options = optimset('LargeScale', 'off', 'GradObj','off','Hessian','off',...
                             'Display','off','DerivativeCheck','off',...
                             'Diagnostics','off','TolFun',1e-5,'TolX', 1e-5,...
                             'MaxFunEvals',1000, 'MaxIter', 1000);

	[gamma_AIPW] = fminunc('AIPW_fun', start, options, Y, X, D, alpha, m);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the 3-step SE using an external program: %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	[AIPW_SE] = AIPW_SE_prog(alpha, beta, gamma_AIPW, Y, X, D, m, N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the simple SE %
%%%%%%%%%%%%%%%%%%%%%%%%%%%

	p_hat = exp(X*alpha)./(1+exp(X*alpha));
	I = (D.*Y - m.*D + m.*p_hat)./p_hat - gamma_AIPW;
	AIPW_SE_simple = I.^2;
	AIPW_SE_simple = (mean(AIPW_SE_simple)/N)^0.5;
	