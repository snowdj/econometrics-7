% AIPW program (2/3) - see AIPW.m for more details
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [out] = IPW(gamma, Y, X, D, alpha, m) 


	p_hat = exp(X*alpha)./(1+exp(X*alpha));
	s = D.*(Y - gamma)./p_hat;
	s = s - (m-gamma).*(D - p_hat)./p_hat;
	out = mean(s)^2;

