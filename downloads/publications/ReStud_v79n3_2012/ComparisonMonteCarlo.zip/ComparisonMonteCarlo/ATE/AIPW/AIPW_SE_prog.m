% AIPW program (3/3) - see AIPW.m for more details
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [AIPW_SE] = AIPW_SE_prog(alpha, beta, gamma, Y, X, D, m, N)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate some preliminary values: %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	M = size(alpha,1);

	p_hat = exp(X*alpha);
	p_hat = p_hat./(1 + p_hat);

	dp_dalpha = exp(X*alpha);
	dp_dalpha = dp_dalpha./(1 + dp_dalpha).^2;
	dp_dalpha = X.*repmat(dp_dalpha, [1 M]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the three moment conditions and the inner term: %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	m_1 = D - p_hat;
	m_1 = m_1./((1-p_hat).*p_hat);
	m_1 = dp_dalpha .* repmat(m_1, [1 M]);

	m_2 = repmat(D, [1 M]).*X.*repmat(Y - X*beta, [1 M]);

	m_3 = D.*(Y - gamma)./p_hat - (X*beta-gamma).*(D - p_hat)./p_hat;

	m_all = [m_1, m_2, m_3];
	size_M = size(m_all,2);

	mm = repmat(reshape(m_all', [size_M 1 N]), [1 size_M 1]).*repmat(reshape(m_all', [1 size_M N]), [size_M 1 1]);
	mm = mean(mm,3);
	

	%%%%%%%%%%%%%%%%%
	% Construct M_0 %
	%%%%%%%%%%%%%%%%%
	
	E_m_1_alpha = -reshape(dp_dalpha', [1 M N]);
	E_m_1_alpha = repmat(reshape(X', [M 1 N]), [1 M 1]).*repmat(E_m_1_alpha, [M 1 1]);
	E_m_1_alpha = mean(E_m_1_alpha,3);

	E_m_2_beta = repmat(reshape(X', [1 M N]), [M 1 1]).*repmat(reshape(X', [M 1 N]), [1 M 1]);
	E_m_2_beta = -repmat(reshape(D', [1 1 N]), [M M 1]).*E_m_2_beta;
	E_m_2_beta = mean(E_m_2_beta,3);
	
	E_m_3_alpha = dp_dalpha.*repmat((D.*(X*beta - Y)./p_hat.^2), [1 M]);
	E_m_3_alpha = mean(E_m_3_alpha);

	E_m_3_beta = -X.*repmat((D - p_hat)./p_hat, [1 M]);
	E_m_3_beta = mean(E_m_3_beta);

	E_m_3_gamma = -1;

	%%%%%%%%%%%%%%%%%%%%%%%
	% Put things together %
	%%%%%%%%%%%%%%%%%%%%%%%
	


	M_0 = [ E_m_1_alpha, 	zeros(M,M), 	zeros(M,1);
			zeros(M,M), 	E_m_2_beta, 	zeros(M,1);
			E_m_3_alpha, 	E_m_3_beta, 	E_m_3_gamma];
				
	var = inv(M_0)*mm*inv(M_0)';
	AIPW_SE = (var(5,5)/N)^.5;
				
