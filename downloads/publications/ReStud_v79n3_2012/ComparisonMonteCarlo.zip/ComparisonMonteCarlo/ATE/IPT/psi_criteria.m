function [psi_crit, psi_crit_1] = psi_criteria(gamma, Y, weights, N_0, N_1, N)

	% Data is organized so that observations are along the columns:

        [psi, psi_1] = PSI_eval(Y, gamma, N_0, N_1, N);

		weights = weights';

		psi_crit = (mean(repmat(weights, [size(psi,1) 1]).*psi)).^2;
		
		psi_crit_1 = 2*mean(repmat(weights, [size(psi,1) 1]).*psi,2);
		psi_crit_1 = psi_crit_1*mean(repmat(reshape(weights, [1 1 N_1]), [size(psi,1) size(psi,1) 1]).*psi_1,3);

end