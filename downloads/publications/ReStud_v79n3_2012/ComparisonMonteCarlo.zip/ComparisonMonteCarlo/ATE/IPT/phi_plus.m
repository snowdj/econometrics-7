function [phi_0, phi_1, phi_2] = phi_plus(x, Q_0, computation_params, type);

% Note: x should be (N x 1)
% I am no longer using the distinction for different derivative values.
% They are all calculated at the same time.
%   0: phi itself
%   1: first derivative
%   2: second derivative

% Here are the definitions for type:
%   1: Inverse logistic tilting
%   2: Empirical Likelihood

if type==1,

    % Calculate two scalars that are used throughout:

        G_inv_Q_0=log(Q_0/(1-Q_0));
        k_Q_0 = -1/(1-Q_0);

    % Now calculate the different "Psi's" using the most recent notation:

        v = -k_Q_0*x - G_inv_Q_0;
		phi_0 = -x*Q_0 + Q_0/k_Q_0 .* exp(v);
		phi_1 = -Q_0 - Q_0.*exp(v);
		phi_2 = k_Q_0*Q_0.*exp(v);

    % The values used for correction are from the "Spring 2007" note on
    % Computation:
    
        x_star = computation_params(1,1);
        a = computation_params(2,1);
        b = computation_params(3,1);
        c = computation_params(4,1);

		phi_0 = phi_0 .* (x < x_star) + (a + b.*x + 0.5*c.*x.^2) .* (x >= x_star);
		phi_1 = phi_1 .* (x < x_star) + (b + c.*x) .* (x >= x_star);
		phi_2 = phi_2 .* (x < x_star) + (c) .* (x >= x_star);
            
end

if type==2,
       
        % Need the size of t_i to do the smoothing: I need to do the EL fix:
        N = size(x,1);

		e = 1 - 1/N;
        phi_0 = (log(1-x)).*(x<=e)     + (log(1/N) - 1.5 + 2*(1-x)*N - 0.5*(1-x).^2.*N^2).*(x>e);
        phi_1 = (-(1-x).^(-1)).*(x<=e) + (-2*N + (1-x)*N^2).*(x>e);
        phi_2 = (-(1-x).^(-2)).*(x<=e) + (-N^2).*(x>e);

end


