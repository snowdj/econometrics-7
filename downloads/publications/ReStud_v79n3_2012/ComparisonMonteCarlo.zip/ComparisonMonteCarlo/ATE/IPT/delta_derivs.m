function [delta_FOC, delta_SOC] = delta_derivs(delta, t_i, t_0, kappa, computation_params, type)


% Calculate the phi's which are used in the FOC and SOC:

[phi_plus_0_x, phi_plus_1_x, phi_plus_2_x] = phi_plus(t_i'*delta, kappa, computation_params, type);

%%%%%%%%%%%
% The FOC %
%%%%%%%%%%%

	% This is (t_0 + phi_plus_1_x*t_i):
	
	delta_FOC = repmat(reshape(phi_plus_1_x, [1 size(t_i,2)]), [size(t_i,1) 1]);
	delta_FOC = t_0 + mean(delta_FOC.*t_i,2);
	    	    
%%%%%%%%%%%
% The SOC %
%%%%%%%%%%%

    % This is just phi_plus_2_x*t_i*t_i':
	
	t_iXt_i = repmat(reshape(t_i, [size(t_i,1) 1 size(t_i,2)]), [1 size(t_i,1) 1]);
	t_iXt_i = t_iXt_i .* repmat(reshape(t_i, [1 size(t_i,1) size(t_i,2)]), [size(t_i,1) 1 1]);
	t_iXt_i = t_iXt_i .* repmat(reshape(phi_plus_2_x, [1 1 size(t_i,2)]), [size(t_i,1) size(t_i,1)]);
	
	delta_SOC=mean(t_iXt_i,3);
	