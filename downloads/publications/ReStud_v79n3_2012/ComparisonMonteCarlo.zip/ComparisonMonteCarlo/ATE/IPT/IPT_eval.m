function [IPT_val] = IPT_eval(delta, t_0, t_i, kappa, computation_params, type)

% This calculates the sample average for the IPT function value I am trying to estimate: 

[phi_plus_x, phi_plus_1_x, phi_plus_2_x] = phi_plus(t_i'*delta, kappa, computation_params, type);

% IPT_val is the quantity I am trying to maximize:

IPT_val = t_0'*delta + mean(phi_plus_x);