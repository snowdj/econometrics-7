function [t_i, delta_SV] = calc_t_i(h_z, t_0)

	% First I create t_i:

		t_i = [ones(size(h_z,1),1), h_z]';

    % Calculate the SV for delta as specified by Bryan in an older version of the note:
    % - Page 21 of the 10/12/2006 draft
    % - delta_SV should be ([1 + M] x 1)

		t_iXt_i = repmat(reshape(t_i, [size(t_i,1) 1 size(t_i,2)]), [1 size(t_i,1) 1]);
		t_iXt_i = t_iXt_i.*repmat(reshape(t_i, [1 size(t_i,1) size(t_i,2)]), [size(t_i,1) 1 1]);
		t_iXt_i = sum(t_iXt_i,3);

		delta_SV= pinv(t_iXt_i)*(size(t_i,2)*t_0 - sum(t_i,2));
