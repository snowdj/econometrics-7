function [IPT_SE] = var_IPT(D, Y, X, delta, gamma, N_0, N_1, N, t_0, t_i, Q, computation_params, type, moments)

% This calculates the variance for the just-identified case:
% - I try to follow the notation in the note exactly.  I construct the
%   m_N(theta) so that the rows are moments and the columns are observations.
%   The `control' observations with D_0i = 1 are the first block of columns.

	[phi_plus_x, phi_plus_1_x, phi_plus_2_x] = phi_plus(t_i'*delta, Q, computation_params, type);

	A_1= repmat(reshape(phi_plus_1_x, [1 N_1]), [size(t_i,1) 1]);
	A_1= repmat(t_0, [1 N_1]) + A_1.*t_i;
	A_1 = [zeros(size(t_i,1),N_0), A_1];
	A_1 = A_1 * (N/N_1);

	[psi, psi_1] = PSI_eval(Y(N_0 + 1 : N), gamma, N_0, N_1, N);
	A_2 = repmat(reshape(phi_plus_1_x, [1 N_1]), [size(psi,1) 1]);
	A_2 = -A_2.*psi;
	A_2 = [zeros(size(psi,1),N_0), A_2];
	A_2 = A_2 * (N/N_1);

    [h_z, h_z_deriv] = h_Z_eval(X, N_0, N_1, N);
    h_z_all = (X - repmat(mean(X), [N 1]))';
	A_3 = h_z_all;

	varsigma_0 = N_0/N;
	D_0i = (ones(N,1)-D)';
	D_1i = D';
	A_4 = [D_1i - Q; D_0i - varsigma_0];

	m_i_theta = [A_1;A_2;A_3;A_4];

	PHI = repmat(reshape(t_i, [size(t_i,1) 1 N_1]), [1 size(t_i,1) 1]);
	PHI = PHI.*repmat(reshape(t_i, [1 size(t_i,1) N_1]), [size(t_i,1) 1 1]);
	PHI = repmat(reshape(phi_plus_2_x, [1 1 N_1]), [size(t_i,1) size(t_i,1) 1]).*PHI;
	PHI = mean(PHI,3);

	XI = repmat(reshape(psi, [size(psi,1) 1 N_1]), [1 size(t_i,1) 1]);
	XI = XI.*repmat(reshape(t_i, [1 size(t_i,1) N_1]), [size(psi,1) 1 1]);
	XI = repmat(reshape(phi_plus_2_x, [1 1 N_1]), [size(psi,1) size(t_i,1) 1]).*XI;
	XI = -mean(XI,3);
	
	GAMMA = repmat(reshape(phi_plus_1_x, [1 1 N_1]), [size(psi,1) size(psi,1) 1]);
	GAMMA = -mean(GAMMA.*psi_1,3);
	
	% For calculating alpha, beta and eta I only want the last elements of h_z_deriv where D_1i = 1:
	% - I will start by calculating the derivative of t_i with respect to zeta which is used in both:

	%%%%%%%%%
	% alpha %
	%%%%%%%%%

	dt_i_dzeta = h_z_deriv(:,:,N_0 + 1:N);
	dt_i_dzeta = [zeros(1,size(t_i,1)-1,N_1); dt_i_dzeta];

	t_iXdelta = repmat(reshape(t_i, [size(t_i,1) 1 N_1]), [1 size(t_i,1) 1]);
	t_iXdelta = t_iXdelta .* repmat(reshape(delta, [1 size(t_i,1) 1]), [size(t_i,1) 1 N_1]);
	
	% Multiplying a [(1+M) x (1+M) x N_1] x [(1+M) x M x N_1] is not trivial in Matlab.
	% I will (unfortunately!) do it as a loop.

		for i=1:N_1,
			alpha(:,:,i) = t_iXdelta(:,:,i)*dt_i_dzeta(:,:,i);
		end

	alpha = repmat(reshape(phi_plus_2_x, [1 1 N_1]), [size(t_i,1), size(t_i,1) - 1, 1]).*alpha;
	alpha = alpha + repmat(reshape(phi_plus_1_x, [1 1 N_1]), [size(t_i,1), size(t_i,1) - 1, 1]).*dt_i_dzeta;
	alpha = mean(alpha,3);
	
	%%%%%%%%
	% beta %
	%%%%%%%%
	
	psiXdelta = repmat(reshape(psi, [size(psi,1) 1 N_1]), [1 size(t_i,1) 1]);
	psiXdelta = psiXdelta .* repmat(reshape(delta, [1 size(t_i,1) 1]), [size(psi,1) 1 N_1]);
	
	% Here I multiply a [K x (1+M) x N_1] x [(1+M) x M x N_1]:
		
		for i=1:N_1,
			beta(:,:,i) = psiXdelta(:,:,i)*dt_i_dzeta(:,:,i);
		end

	beta = repmat(reshape(phi_plus_2_x, [1 1 N_1]), [size(psi,1), size(t_i,1) - 1, 1]).*beta;
	beta = -mean(beta,3);

	%%%%%%%
	% eta %
	%%%%%%%

		eta = mean(h_z_deriv,3);

	% For calculating mu and epsilon, I need to calculate the 1xN_1 dphi_dQ:
	
	if type == 1,
		x = t_i'*delta;
		dphi_dQ = x/(1-Q) - log(Q/(1-Q));
		dphi_dQ = exp(dphi_dQ);
		dphi_dQ = -1 - dphi_dQ + Q*dphi_dQ.*(x/(1-Q)^2 + 1/(Q*(1-Q)));
		dphi_dQ = dphi_dQ';
	elseif type == 2,
		dphi_dQ = zeros(1,N_1);
	end

	mu = mean(repmat(dphi_dQ, [size(t_i,1) 1]).*t_i,2);
	epsilon = -mean(repmat(dphi_dQ, [size(psi,1) 1]).*psi,2);
	
	phi = [-1;0];
	varpi = [0;-1];

	M_0 = [ PHI, zeros(size(A_1,1), size(gamma,1)), 		alpha, 					mu, 					zeros(size(A_1,1),1);
			XI,  GAMMA, 									beta,					epsilon, 				zeros(size(A_2,1),1);
			zeros(size(h_z',1),size(delta,1)), zeros(size(A_3,1),size(gamma,1)), eta,zeros(size(h_z',1),1),	zeros(size(A_3,1),1);
			zeros(2,size(delta,1)), zeros(2,size(gamma,1)), zeros(2,size(A_3,1)), 	phi,			 		varpi];


	LAMBDA = repmat(reshape(m_i_theta, [size(m_i_theta,1) 1 size(m_i_theta,2)]), [1 size(m_i_theta,1) 1]);
	LAMBDA = LAMBDA.*repmat(reshape(m_i_theta, [1 size(m_i_theta,1) size(m_i_theta,2)]), [size(m_i_theta,1) 1 1]);
	LAMBDA = mean(LAMBDA,3);
	
	IPT_var = pinv(M_0)*LAMBDA*pinv(M_0)/size(m_i_theta,2);

	IPT_SE = diag(IPT_var).^.5;
	