function [h_z, h_z_deriv] = h_Z_eval(X, N_0, N_1, N)

	% Here the user needs to calculate the moments that will be matched:

	%%%%%%%%%%%%%%%%%%
	% Construct h(z) % 
	%%%%%%%%%%%%%%%%%%
	
		zeta_0 = mean(X);
        h_z = X(N_0 + 1: N,:) - ones(N_1,1)*zeta_0;

	%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Construct  dh(z)/dzeta %
	%%%%%%%%%%%%%%%%%%%%%%%%%%
	
		% This should be M x M x N:

		M = size(X,2);
		h_z_deriv = -repmat(reshape(eye(M), [M M 1]), [1 1 N]);