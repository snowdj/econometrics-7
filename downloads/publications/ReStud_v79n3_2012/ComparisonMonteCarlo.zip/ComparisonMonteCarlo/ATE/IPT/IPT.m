% Implements the IPT estimator as discussed in EGP (2008)
%
% -> In addition to the point estimate and the SE, we also output a binary indicating whether
% 	 the estimator failed to converge.
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [gamma_IPT, gamma_SE, fail_converge] = IPT(D, Y, X)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This program was initially designed to calculate two analagous estimates: %
% 1) Inverse logistic tilting												%
% 2) Empirical Likelihood													%
% -> EGP (2008) only focused on (1), so that is the default here			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	type = 1;
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sort the data so that treated/untreated are grouped: %
% - Select the treated/control groups				   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	N = size(D,1);
	N_1 = sum(D);
	N_0 = N - N_1;

	data = [D, Y, X];
	data = sortrows(data,1);
	D = data(:,1);
	Y = data(:,2);
	X = data(:, 3: 3 + size(X,2) - 1);

%%%%%%%%%%%%%%%%%%%
% Calculate h(z): %
% - h(z) is N x M %
%%%%%%%%%%%%%%%%%%%

    [h_z] = h_Z_eval(X, N_0, N_1, N);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate t_0 			 %
% - t_0 is ([1 + M] x 1) %
%%%%%%%%%%%%%%%%%%%%%%%%%%

    t_0 = [1, zeros(1,size(h_z,2))]';

%%%%%%%%%%%%%%%%%
% Generate q_0: %
%%%%%%%%%%%%%%%%%

	Q_0 = N_1 / N;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate smoothing parameters	   %
% - These are to take care of problems %
%   with the tails.					   %
% - Used in the ILT program			   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
	ratio = (N - Q_0)/(1-Q_0);
	
	c = -ratio;
	b = -N + (N - Q_0)*log(ratio);
	a = -(1 - Q_0)*(N - Q_0)*(0.5*(log(ratio))^2 - log(ratio) + 1);
    x_star = (1 - Q_0)*log(ratio);

    computation_params = [x_star;a;b;c];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Calculate:				   %
%	- t_i					   %
%	- Starting value for delta %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	[t_i,delta_SV] = calc_t_i(h_z, t_0);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve for delta following equation (20) of section 5.2.1 of the 5/16/07 note %
% - Recover the weights and various parameters								   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	% Set optimization options

    options_delta = optimset('LargeScale', 'on', 'GradObj','on','Hessian','on',...
                             'Display','off','DerivativeCheck','off',...
                             'Diagnostics','off','TolFun',1e-10,'TolX', 1e-10,...
                             'MaxFunEvals', 10000, 'MaxIter', 10000);

	[delta_IPT,fval,exitflag,output,grad,hessian] = fminunc('IPT_criteria', delta_SV, options_delta, Q_0, t_0, t_i, computation_params, type);

	iterations = output.iterations;

	if exitflag == 0,
		fail_converge = 1;
	else,
		fail_converge = 0;
	end
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check the weights to make sure the fit is good %
% - This only checks moments used in h_z 		 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	      
	      
	[phi_plus_0_x, phi_plus_1_x, phi_plus_2_x] = phi_plus(t_i'*delta_IPT, Q_0, computation_params, type);

	pi_rho = -phi_plus_1_x/N;

	zeta_0 = mean(X);
    h_z_all = X - ones(N,1)*zeta_0;
	t_i_all = [ones(N,1), h_z_all]';
    G_inv_Q_0=log(Q_0/(1-Q_0));
    k_Q_0 = -1/(1-Q_0);
	G = k_Q_0*t_i_all'*delta_IPT + G_inv_Q_0;
	prop = exp(G)./(1+exp(G));

	mean_P = mean(prop);
	median_P = median(prop);

	checkweights = 100*(pi_rho'*X(N_0 + 1:N,:) - mean(X))./(mean(X));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve for gamma using Psi			  %
% - Psi is called inside psi_criteria %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	% Starting value for gamma:
	gamma_SV = mean(Y);

    options_gamma = optimset('LargeScale', 'off', 'GradObj','on','Hessian','off',...
                             'Display','off','DerivativeCheck','off',...
                             'Diagnostics','off','TolFun',1e-10,'TolX', 1e-10,...
                             'MaxFunEvals',1000, 'MaxIter', 1000);

	[gamma_IPT, fval, exitflag] = fminunc('psi_criteria', gamma_SV, options_gamma, Y(N_0 + 1:N), pi_rho, N_0, N_1, N);

	% This calculates the SEs for theta:
	theta_SE = var_IPT(D, Y, X, delta_IPT, gamma_IPT, N_0, N_1, N, t_0, t_i, Q_0, computation_params, type);

	gamma_SE = theta_SE(size(t_i,1)+1,1);

end