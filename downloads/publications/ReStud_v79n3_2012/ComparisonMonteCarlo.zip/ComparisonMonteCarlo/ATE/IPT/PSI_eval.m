function [psi, psi_1] = PSI_eval(Y, gamma, N_0, N_1, N)

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% User needs to specify the moment that is being solved:	   %
	% - Here I am trying to find the mean of income (3rd variable) %
	%   (I want to minimize [Y - gamma])					  	   %
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	% psi should be K x N_1
	psi = Y' - gamma;
	
	% psi_1 should be K x K x N_1:
	psi_1 = -ones(1,1,N_1);

end