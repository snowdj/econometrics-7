function [IPT_val, delta_FOC, delta_SOC] = IPT_criteria(delta, Q, t_0, t_i, computation_params, type)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function solves for (1 + M) x 1 vector of tilting parameters (delta)  %
% - First and second derivatives are also calculated.                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
		
		% First I evaluate the IPT function at the parameter values:
		% - I put in the negative symbol because we are minimizing but want to find the maximumum value:
				
		IPT_val = -IPT_eval(delta, t_0, t_i, Q, computation_params, type);
		
		% Now I calculate the first and second derivates for delta:

		[delta_FOC, delta_SOC] = delta_derivs(delta, t_i, t_0, Q, computation_params, type);
		
		% I also need the opposite of the derivative/hessian as I am using the opposite of
		% the functional value:
		
		delta_FOC = -delta_FOC;
		delta_SOC = -delta_SOC;

        
    