% CHT program (2/3) - see CHT.m for more details
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [CHT_crit] = CHT_criteria(gamma, Y, N, N_0, N_1, K, Q_K, Q_N1, inv_Q_N1)

	% First I need to create the [1 x N_1] vector of moments (we only use those for D = 1):

		psi_Z_gamma = Y(N_0+1:N,:) - repmat(gamma, [N_1 1]);
		psi_Z_gamma = psi_Z_gamma';
		
	% Multiply each element by the appropriate vector of Q_N1:
	% -> Note that what follows is specific to the case with only one moment:
	
		E_hat = Q_N1';
		E_hat = repmat(psi_Z_gamma, [K 1]).*E_hat;
		E_hat = sum(E_hat,2)'*inv_Q_N1;
 		
	% Now calculate what goes into the GMM:
		% Note that Q_K is [K x N] and E_hat is [1 x K]:
	
		E_hat_X = repmat(E_hat', [1 N]);
		E_hat_X = E_hat_X .* Q_K;
		E_hat_X = sum(E_hat_X,1);
		E_hat_X = mean(E_hat_X,2);
		
		CHT_crit = E_hat_X.^2;
		
end