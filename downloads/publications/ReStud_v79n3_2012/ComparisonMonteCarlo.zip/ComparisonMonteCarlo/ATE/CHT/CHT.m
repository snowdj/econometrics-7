% This implements the Chen, Hong, Tarozzi (2007) imputation estimator of the ATE as discussed 
% in the technical appendix
% -> This is the first of three programs for CHT (1/3)
% -> Calls two functions:
%		1) Objective function for CHT (CHT_criteria.m) (2/3)
%		2) Function that calcluates the variance for CHT (CHT_variance.m) (3/3)
%
% -> Note that this uses the logit function of James P. LeSage
%		- Available at http://www.spatial-econometrics.com/
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [gamma_CHT, CHT_SE] = CHT(D, Y, X)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sort the data so that treated/untreated are grouped: %
% - Select the treated/control groups				   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	N = size(D,1);
	N_1 = sum(D);
	N_0 = N - N_1;

	data = [D, Y, X];
	data = sortrows(data,1);
	D = data(:,1);
	Y = data(:,2);
	X = data(:, 3: 3 + size(X,2) - 1);

	% Construct a (K x N) matrix of the (K x 1) basis functions for all N observations.  The
	% individual columns are called q_K but together I call them Q_K.  This K includes a
	% constant term (which is included by adding a column of ones):

	Q_K = [ones(N,1),X]';
	K = size(Q_K,1);

%%%%%%%%%%%%%%%%%%
% Construct Q_N1 %
%%%%%%%%%%%%%%%%%%

	% Q_N1 is a [N_1 x K] matrix of the elements of q_K where D = 1
	
		Q_N1 = Q_K(:,N_0+1:N)';

	% In order to save a bit of processing time in the optimization and to simplify notation, I calculate
	% (Q_N1'Q_N1)^-1:
	
		inv_Q_N1 = pinv(Q_N1'*Q_N1);

%%%%%%%%%%%%%%%%%%%%%
% Solving for gamma %
%%%%%%%%%%%%%%%%%%%%%

	% Now I am in a position where I need to use fminunc

	% Starting value for gamma:
	gamma_SV = mean(Y);

    options_gamma = optimset('LargeScale', 'off', 'GradObj','off','Hessian','off',...
                             'Display','off','DerivativeCheck','off',...
                             'Diagnostics','off','TolFun',1e-10,'TolX', 1e-10,...
                             'MaxFunEvals',1000, 'MaxIter', 1000);

	[gamma_CHT] = fminunc('CHT_criteria', gamma_SV, options_gamma, Y, N, N_0, N_1, K, Q_K, Q_N1, inv_Q_N1);
	
	CHT_SE = CHT_variance(gamma_CHT, Y, D, N, N_0, N_1, K, Q_K, Q_N1, inv_Q_N1); 

