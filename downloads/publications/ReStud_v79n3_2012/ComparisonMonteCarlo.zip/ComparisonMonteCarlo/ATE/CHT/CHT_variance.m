% CHT program (3/3) - see CHT.m for more details
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code

function [CHT_var] = CHT_variance(gamma, Y, D, N, N_0, N_1, k, Q_K, Q_N1, inv_Q_N1)

	% First I need to create the [1 x N1] vector of moments:

		psi_Z_gamma = Y(N_0+1:N,:) - repmat(gamma, [N_1 1]);
		psi_Z_gamma = psi_Z_gamma';
		
	% Multiply each element by the appropriate vector of Q_N1:
	% -> Note that what follows is specific to the case when I only have one moment:
	
		E_hat = Q_N1';
		E_hat = repmat(psi_Z_gamma, [k 1]).*E_hat;
		E_hat = sum(E_hat,2)'*inv_Q_N1;
 		
	% Now calculate the E:
		% Note that q_K is [K x N] and E_hat is [1 x K]:
	
		E_hat_X =repmat(E_hat', [1 N]);
		E_hat_X = E_hat_X .* Q_K;
		E_hat_X = sum(E_hat_X,1);

		% This does the same thing in two lines:
		%	X = q_K(:,N_0+1:N);
		%	test = m_Z*X'*inv(X*X')*q_K;

	% Now I calcuate the term for each i:
	
		psi_Z_gamma = Y - repmat(gamma, [N 1]);
		psi_Z_gamma = psi_Z_gamma';
		
		% Need to calculate the propensity score:
		% - I use a canned logit routine
		
			cd Tools

			alpha = logit(D,Q_K');
			alpha_logit = alpha.beta;
	
			cd ..
		 
		% And now I calculate the propensity score for each observation:
		
		    p_hat = exp(Q_K'*alpha_logit)./(1 + exp(Q_K'*alpha_logit));
		    
		% And finally I can calculate the influence function and then the variance:

		CHT_var = E_hat_X + D'./p_hat'.*(psi_Z_gamma - E_hat_X);
		CHT_var = (mean(CHT_var.^2)/N)^0.5;
		
end