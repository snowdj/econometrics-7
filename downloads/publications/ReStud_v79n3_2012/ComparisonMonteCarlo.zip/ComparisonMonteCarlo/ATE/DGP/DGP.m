% This is the data generating process for the Monte Carlo discussed in EGP (2008)
% -> Note that this calls the 'randraw.m' routine
%
% Daniel Egel, Bryan Graham and Cristine Pinto - UC Berkeley
% Primary contact for paper: bgraham@econ.berkeley.edu 
% Primary contact for code: egel@econ.berkeley.edu
% September 2008
%
% Note: We unfortunately cannot respond to all requests for assistance with implementation of this code


function [Y_obs, D, X, oracle, TWE] = DGP(N, design);


	if design == 1,
		cond = 1;
		prop = 1;
		sigma_u = 0.161834;
	elseif design == 2,
		cond = 2;
		prop = 1;
		sigma_u = 0.173269;
	elseif design == 3,
		cond = 1;
		prop = 2;
		sigma_u = 0.174096;
	elseif design == 4,
		cond = 2;
		prop = 2;
		sigma_u = 0.186398;
	end


	if cond == 1,
		alpha_0 = 0;
		alpha_1 = -0.25;
		alpha_3 = 0;
		a = 0.5;
		b = 0.2;
	elseif cond == 2,
		alpha_0 = -0.1251;
		alpha_1 = -0.25;
		alpha_3 = 0.5;
		a = 0.5;
		b = 0.2;
	end
	if prop == 1,
		beta_0 = 0;
		beta_1 = 2.19722;
		beta_2 = 0;
		c = 0.15;
	elseif prop == 2,
		beta_0 = 2;
		beta_1 = 4.19722;
		beta_2 = -4;
		c = 0.15;
	end	

	X = 2*rand([N,1]) - 1;
	U = sigma_u*randn([N,1]);
	V = randraw('logistic',[0 1], [N,1]);

	Y_all = alpha_0 + alpha_1*X + alpha_3*normcdf((X-a)/b) + U;
	D = beta_0 + beta_1*X + beta_2*normcdf(X/c);
	prop = exp(D)./(1 + exp(D));
	D = (D - V >= 0);
	Y_obs = Y_all.*D;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the output parameters %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	oracle_SE = (var(Y_all)/N)^0.5;
	oracle = [mean(Y_all), oracle_SE];
	
    TWE = mean(Y_obs./prop);
    TWE_SE = (var(Y_obs./prop)/N)^0.5;
	TWE = [TWE, TWE_SE];
