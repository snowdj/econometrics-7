function [delta_IPT VCOV_delta_IPT HESS_IPT] = IPT_LOGIT(treat,D, h_X, silent, sw);

% This function computes the IPT estimates of the logit binary choice
% model: Pr(D=1|X=x)= exp(x'delta)/[1+exp(x'delta)]. The algorithm is as 
% described in the Appendix of Graham, Pinto and Egel (2010).

% INPUTS
% D      : N x 1 vector of binary outcomes
% h_X    : X is an M x N matrix of covariates (assumes a constant is excluded)
%         (Note: t(X) in the paper equals (1,h_X')'
% silent : when silent = 1 optimization output is suppressed and
%          optimization is by Newton-Raphson with lower tolerances.
%          Otherwise optimization starts with a few Newton-Raphson steps
%          and then switches to a quasi-Newton search. 
% sw     : N x 1 vector of known sampling weights (assumed to have mean
%          one)

% OUTPUTS
% gamma_IPT         : IPT estimates of logit coefficients
% VCOV_delta_IPT    : large sample covariance of estimates
% HESS_IPT          : Hessian of IPT criterion function (this corresponds
%                     to the Jacobian of the IPT sample moments and hence 
%                     can be useful for constructing standard errors when IPT_LOGIT()
%                     is the first step of a two-step procedure).

% Functions called  : IPT_LOGIT_CRIT() and IPT_LOGIT_PHI()

[N M] = size(h_X);          % Number of observations and covariates
t_X   = [ones(N,1) h_X];    % Add a constant to the regressor matrix

f_ipt_logit_crit = @(x)IPT_LOGIT_CRIT(x, treat, D, t_X, M, N, sw);  % define objective function

% Set optimization parameters
if silent == 1      
    % Use Newton-Raphson with lower tolerances
    options_delta = optimset('LargeScale','on','GradObj','on','Hessian','on',...
                             'Display','off','TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',1000,'MaxIter',1000);
    delta_SV = (t_X'*t_X) \ (t_X'*D);          % Linear probability starting values for logit          
else
    % Take a few Newton-Raphson steps to get starting values, then do a
    % quasi-newton search
    options_delta = optimset('LargeScale','on','GradObj','on','Hessian','on',...
                             'Display','off','TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',10,'MaxIter',10); 
    
    delta_SV = fminunc(f_ipt_logit_crit,  zeros(1+M,1), options_delta);
    options_delta = optimset('LargeScale','off','GradObj','on','Hessian','off',...
                             'Display','off','TolFun',1e-25,'TolX',1e-12,'MaxFunEvals',10000,'MaxIter',10000);    
end                                      

[delta_IPT,CRIT_IPT,exitflag,output,SCORE_IPT,HESS_IPT] = fminunc(f_ipt_logit_crit, delta_SV, options_delta);  % compute delta_IPT   

% compute sampling variance of IPT estimate
p_X = 1+exp(-t_X*delta_IPT);
m_IPT = repmat((D ./ p_X - 1),1,1+M) .* t_X;
V_m = m_IPT'*m_IPT;
VCOV_delta_IPT = inv((HESS_IPT/N)'*inv(V_m)*(HESS_IPT/N))/N;
