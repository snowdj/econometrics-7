%-------------------------------------------------------------------------%
%- This M file and the accompanying Stata files reproduce                -%
%- estimation results presented in the paper "Inverse                    -%
%- Proability Tilting for Moment Condition Models with Missing Data".    -% 
%- These files are provided "as is". I am unable to assist with their    -%
%- interpretation or use. However please do feel free to e-mail me if    -%
%- you find any mistakes at degel@rand.org. This file generates          -%
%- a MATLAB diary file Lalonde_Empirical_Example.log.                    -%             
%-------------------------------------------------------------------------%

clear;

%-------------------------------------------------------------------------%
% Load Lalonde ESTIMATION SAMPLE	                                     -%
%-------------------------------------------------------------------------%

% NOTE: Adjust the directory reference below to point to the directory
% where you have placed the NSW data (downloaded from 
% http://www.nber.org/~rdehejia/nswdata.html)

	load Data/nsw_treated.txt;			
	load Data/nsw_control.txt;
	data = [nsw_control; nsw_treated];


% Create generic weights for the Lalonde data:

	sample_wgts = repmat(1/size(data,1),size(data,1),1);

% Create generic household ids:

	hh_ids = find(data(:,1)~=2);

%-------------------------------------------------------------------------%
% ORGANIZE DATA                                                          -%
%-------------------------------------------------------------------------%

D = data(:,1);
N = length(D);
N1 = sum(D);
NG = CountGroupMembers(hh_ids);
G = length(NG);

% normalize sample weights to have mean one
sw = sample_wgts/mean(sample_wgts);

	% Name the columns:
		age=data(:,2);
		educ=data(:,3);
		married=data(:,6);
		nodegree=data(:,7);
		black=data(:,4);
		hispanic=data(:,5);
		re75=data(:,8);
		re78=data(:,9);

	% vector of moments to balance
		h_X = [age educ married nodegree black hispanic re75/1000];
		
	% Normalize moments to be mean one:
		mean_h_X = mean(h_X);
		h_X = h_X./repmat(mean_h_X, [N 1]);
 
 	% Set the outcome variable:
 		DY = re78;

delete('Lalonde_Empirical_Example.log');
diary('Lalonde_Empirical_Example.log');
diary off;

% ------------------------------------------------------------------------%
% IPT point estimates                                                    -%
% ------------------------------------------------------------------------%

% compute IPT point estimates and standard errors
[gamma_IPT, delta_IPT_0, delta_IPT_1, VCOV_gamma_IPT, VCOV_delta_IPT_0, VCOV_delta_IPT_1, w_IPT_0, w_IPT_1] = IPT_ATE(D,DY,h_X,NG,sw);
se_gamma      = sqrt(VCOV_gamma_IPT/G);                % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_IPT ./ se_gamma;                       % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('IPT Point estimates and standard errors')
disp([gamma_IPT se_gamma t_gamma pv_gamma]);

disp('IPT propensity score estimates and standard errors (D=1)')
se_delta_1      = sqrt(diag(VCOV_delta_IPT_1)/G);                	% Asymptotic std. errors for delta_hat
t_delta_1      = delta_IPT_1 ./ se_delta_1;                       	% t-stats
pv_delta_1      = 2*(1-normcdf(abs(t_delta_1)));                 	% p-values (for H0: delta_1=0)      
disp([delta_IPT_1 se_delta_1 t_delta_1 pv_delta_1]);

disp('IPT propensity score estimates and standard errors (D=0)')
se_delta_0      = sqrt(diag(VCOV_delta_IPT_0)/G);                	% Asymptotic std. errors for delta_hat
t_delta_0       = delta_IPT_0 ./ se_delta_0;                       	% t-stats
pv_delta_0      = 2*(1-normcdf(abs(t_delta_0)));                 	% p-values (for H0: delta_0=0)      
disp([delta_IPT_0 se_delta_0 t_delta_0 pv_delta_0]);

% inspect the implicit distribution function estimate (D==1)
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles (D==1)')
sum(w_IPT_1(i))                                  % check weights sum to one
prctile(w_IPT_1(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

% inspect the implicit distribution function estimate (D==0)
i = find(D==0);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles (D==0)')
sum(w_IPT_0(i))                                  % check weights sum to one
prctile(w_IPT_0(i),[0 10 25 50 75 90 100])       % quantiles of weight distribution

disp('Check of covariate balance')
disp('[D=1, D=0, all]')
disp([h_X' * w_IPT_1.*mean_h_X'		h_X' * w_IPT_0.*mean_h_X'	mean(h_X)'.*mean_h_X'])	 % verify `exact balance'
diary off;

% ------------------------------------------------------------------------%
% IPW point estimates                                                    -%
% ------------------------------------------------------------------------%

% compute IPW point estimates and standard errors
[gamma_IPW, VCOV_gamma_IPW, delta_ML, VCOV_delta_ML, w_IPW_1, w_IPW_0] = IPW_ATE(D,DY,h_X,NG,sw);
se_gamma      = sqrt(VCOV_gamma_IPW/G);		                % Asymptotic std. errors for gamma_hat
t_gamma       = gamma_IPT ./ se_gamma;                       % t-stats
pv_gamma      = 2*(1-normcdf(abs(t_gamma)));                 % p-values (for H0: gamma=0)      

diary on;
disp('IPW Point estimates and standard errors')
disp([gamma_IPW se_gamma t_gamma pv_gamma]);

disp('CMLE propensity score estimates and standard errors')
se_delta      = sqrt(diag(VCOV_delta_ML)/G);                 % Asymptotic std. errors for delta_hat
t_delta       = delta_ML ./ se_delta;                        % t-stats
pv_delta      = 2*(1-normcdf(abs(t_delta)));                 % p-values (for H0: delta=0)      
disp([delta_ML se_delta t_delta pv_delta]);

% inspect the implicit distribution function estimate
i = find(D==1);
disp('Sum of probability weights and 0 10 25 50 75 90 100 percentiles')
sum(w_IPW_1(i))                                   % check to see if weights sum to one
prctile(w_IPW_1(i),[0 10 25 50 75 90 100])        % quantiles of weight distribution

disp('Check of covariate balance')
disp('[D=1, D=0, all]')
disp([sum(repmat(w_IPW_1 .* D, 1, size(h_X,2)) .* h_X)'.*mean_h_X'	sum(repmat(w_IPW_0 .* (1-D), 1, size(h_X,2)) .* h_X)'.*mean_h_X' 	mean(h_X)'.*mean_h_X']);    % check balance
diary off;


