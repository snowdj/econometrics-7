function [gamma_IPT, delta_IPT_0, delta_IPT_1, VCOV_gamma_IPT, VCOV_delta_IPT_0, VCOV_delta_IPT_1, w_IPT_0, w_IPT_1] = IPT_ATE(D,DY,h_X,NG,sw)

% This function computes the ATE IPT parameter estimates . Estimation details 
% available in the "Inverse Probability Tilting" paper of Graham, Pinto
% and Egel (2010).

% INPUTS
% D     : N x 1 vector with ith element equal to 1 if ith unit's Y variable is observed
%         and zero otherwise
% DY    : D*Y, with Y the N x K1 matrix of regressors missing at random
% h_X   : h(X) N x M function for IPT computation (does not include a
%         constant)
% NG    : G x 1 vector with gth row equal to the number of units in the gth cluster 
% sw    : N x 1 vector of known sampling weights

% OUTPUTS
% gamma_IPT         : IPT estimate of gamma
% VCOV_gamma _IPT   : estimated large sample covariance of gamma
% delta_IPT_1       : IPT estimates of propensity score parameter for TREATED observations
% delta_IPT_0       : IPT estimates of propensity score parameter for CONTROL observations
% VCOV_delta_IPT_1    : estimated large sample covariance of p-score parameter for TREATED
% VCOV_delta_IPT_0    : estimated large sample covariance of p-score parameter for CONTROL
% w_IPT_1             : IPT probability weights / distribution function estimate (TREATED)
% w_IPT_0             : IPT probability weights / distribution function estimate (CONTROL)

% ----------------------------------------------------------------------------------- %
% - STEP 1 : ORGANIZE DATA                                                          - %
% ----------------------------------------------------------------------------------- %

N       = length(D);       % Number of units in sample
G       = length(NG);      % Number of clusters in sample
N1      = sum(D);          % Number of units with Y observed in the sample  
M       = size(h_X,2);     % Dimension of h_X
sw      = sw/mean(sw);     % normalize sample weights to have mean one

% Organize data to make sure that all the treated observations are at the bottom of the vector:

temp = sortrows([D , DY, sw, h_X],1);
D = temp(:,1);
DY = temp(:,2);
sw = temp(:,3);
h_X = temp(:,4:size(temp,2));
t_X   = [ones(N,1) h_X];    % Add a constant to the regressor matrix

% ----------------------------------------------------------------------------------- %
% - STEP 2 : TWO-STEP IPT ESTIMATION                                                - %
% ----------------------------------------------------------------------------------- %

% Compute weights for treated observations:

[delta_IPT_1 VCOV_delta_IPT_1 HESS_IPT_1] = IPT_LOGIT(1,D,h_X,0,sw);       % IPT estimates of p-score coefficients  
p_X_1 = (1+exp(-t_X*delta_IPT_1)).^-1;

% Compute weights for control observations:

[delta_IPT_0 VCOV_delta_IPT_0 HESS_IPT_0] = IPT_LOGIT(0,D,h_X,0,sw);       % IPT estimates of p-score coefficients  
p_X_0 = (1+exp(-t_X*delta_IPT_0)).^-1;

% ----------------------------------------------------------------------------------- %
% - STEP 3 : COMPUTE IPT ESTIMATES OF GAMMA                                         - %
% ----------------------------------------------------------------------------------- %

w_IPT_1  =  (sw .* (D ./ p_X_1))/N;								% TREATED inverse probability weights
w_IPT_0  =  (sw .* ((1-D) ./ p_X_0))/N;							% UNTREATED inverse probability weights

gamma_IPT = sum(w_IPT_1.*DY) - sum(w_IPT_0.*DY)					% IPT point estimates of gamma        

% ----------------------------------------------------------------------------------- %
% - STEP 4 : ESTIMATE SAMPLING VARIANCE                                             - %
% ----------------------------------------------------------------------------------- %

% Form Jacobian matrix
Ms = (N/G)*[-(sw'*((1-D)./p_X_0))/N			(-(sw .* D .* exp(-t_X*delta_IPT_1) .* (DY))'*t_X/N)			((sw .* (1-D) .* exp(-t_X*delta_IPT_0) .* (DY+gamma_IPT))'*t_X/N); ...
		zeros(1+M,1)					-(HESS_IPT_1/N)												zeros(1+M,1+M); ...
		zeros(1+M,1)					zeros(1+M,1+M)												-(HESS_IPT_0/N)];

% Calculate variance-covariance of the moment function
m = [sw .* (D ./ p_X_1).* DY - sw.*((1-D) ./ p_X_0).*(DY+gamma_IPT) 		(repmat(sw .* (D ./ p_X_1 - 1),1,1+M) .* t_X)		(repmat(sw .* ((1-D) ./ p_X_0 - 1),1,1+M) .* t_X)]';

% calculate covariance matrix of moment vector taking into account
% any within-group dependence/clustering
OMEGA = zeros(2+2*M+1,2+2*M+1);
for g = 1:1:G
    % upper & lower bounds for the g-th group
    n1 = (sum(NG(1:g)) - NG(g)) + 1;                 
    n2 = (sum(NG(1:g)) - NG(g)) + NG(g);                
    
    m_g = sum(m(:,n1:n2),2); 
    OMEGA = OMEGA + m_g*m_g'/G;    
end

VCOV_gamma_IPT  = inv(Ms)*OMEGA*inv(Ms)';
VCOV_gamma_IPT  = VCOV_gamma_IPT(1,1);

