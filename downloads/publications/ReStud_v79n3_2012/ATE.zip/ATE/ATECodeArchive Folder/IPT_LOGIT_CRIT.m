function [CRIT, FOC, SOC, phi1] = IPT_LOGIT_CRIT(delta,treat,D,t_X,M,N,sw)

% This function evaluates the IPT logit criterion function as well as its
% first and second derivatives. It uses the modification of the criterion
% function described in the Appendix of Graham, Pinto and Egel (2010). This
% function is called by IPT_LOGIT(). Variable definitions are as described
% in that function.

if treat == 1
	[phi, phi1, phi2] = IPT_LOGIT_PHI(delta, t_X(N-sum(D)+1:N,:), N);    % compute phi and 1st/2nd derivatives

	phi = [zeros(N-sum(D),1);phi];
	phi1 = [zeros(N-sum(D),1);phi1];
	phi2 = [zeros(N-sum(D),1);phi2];
	
	CRIT    = -sum(sw.* (D .* phi - t_X*delta));           % IPT criterion
	FOC     = -t_X'*(sw.* (D .* phi1 - 1));                % gradient
	SOC     = ((repmat(sw .* D .* phi2,1,1 + M) .* t_X)'*t_X);  % hessian

else
	[phi, phi1, phi2] = IPT_LOGIT_PHI(delta, t_X(1:N-sum(D),:), N);    % compute phi and 1st/2nd derivatives

	phi = [phi;zeros(sum(D),1)];
	phi1 = [phi1;zeros(sum(D),1)];
	phi2 = [phi2;zeros(sum(D),1)];
	
	CRIT    = -sum(sw.* ((1-D) .* phi - t_X*delta));           % IPT criterion
	FOC     = -t_X'*(sw.* ((1-D) .* phi1 - 1));                % gradient
	SOC     = ((repmat(sw .* (1-D) .* phi2,1,1 + M) .* t_X)'*t_X);  % hessian
end