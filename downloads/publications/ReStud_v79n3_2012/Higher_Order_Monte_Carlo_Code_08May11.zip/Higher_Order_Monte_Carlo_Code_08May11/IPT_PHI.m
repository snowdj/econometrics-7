function [phi, phi1, phi2] = IPT_PHI(delta, t_X_Xi, Q, N1)

% This function evaluates the phi+(v) function in Graham, Pinto and Egel
% (2011) as well as its first and second derivatives at a vector of values
% for t(X,Xi)'delta.

% Coefficients on quadratic extrapopulation of phi+(v) (as used to deal
% with restricted domain issues)
c = -(N1 - Q)/(1 - Q);
b = -N1 + (N1 - Q)*log((N1 - Q)/(1 - Q));
a = -(1 - Q)*(N1 - Q)*(0.5*(log((N1 - Q)/(1 - Q)))^2 - log((N1 - Q)/(1 - Q)) + 1);
v_star = (1 - Q)*log((N1 - Q)/(1 - Q)); 

% Evaluation of phi+(v) and derivatives
v          =  t_X_Xi*delta;
phi        =  (v<=v_star) .* (-v*Q - (1-Q)^2*exp(v/(1-Q)))   + (v>v_star) .* (a + b*v + 0.5*c*v.^2);
phi1       =  (v<=v_star) .* (-Q - (1-Q)*exp(v/(1-Q)))       + (v>v_star) .* (b + c*v);
phi2       =  (v<=v_star) .* (- exp(v/(1-Q)))                + (v>v_star) .* c;


