function [gamma_IPT, VCOV_gamma_IPT, ps_coef_IPT, VCOV_ps_coef_IPT, exitflag] = IPT_MAR(D,DY,X);

% This function computes the IPT estimate of the mean of Y when it is
% missing at random (MAR). Notation is as in Graham, Pinto and Egel (2011).
% It also reports estimates of the unnormalized propensity score
% coefficients used by the IPT estimator and estimates of their large
% sample variance.

% INPUTS
% D     : N x 1 vector with ith element equal to 1 if ith unit's Y is observed
%         and zero otherwise
% DY    : D*Y, with Y the N x 1 vector of outcomes
% X     : X, N x M matrix of covariates

% OUTPUTS
% gamma_IPT         : IPT estimate of gamma
% VCOV_gamma_IPT    : estimated large sample covariance of gamma
% ps_coef_IPT       : unnormalized IPT propensity score coefficients
% VCOV_ps_coef_IPT  : estimated large sample covariance for unnormalized
%                     p-score coefficients

% ----------------------------------------------------------------------------------- %
% - STEP 1 : ORGANIZE DATA                                                          - %
% ----------------------------------------------------------------------------------- %

N       = length(D);      % Number of units in sample  
N1      = sum(D);         % Number of units with Y observed in the sample  
M       = size(X,2);      % Dimension of X

% ----------------------------------------------------------------------------------- %
% - STEP 2 : SOLVE FOR IPT WEIGHTS/DELTA                                            - %
% ----------------------------------------------------------------------------------- %

Q_hat       = N1/N;       % Marginal probability of missingness                    
Xi_hat      = mean(X);    % Marginal mean of variables whose means are to be "matched"
i           = find(D==1); % Indices for complete case subsample
t_X_Xi      = [ones(N1,1) X(i,:) - repmat(Xi_hat,N1,1)]; % Form t(X,Xi) vector (complete case only)
t0          = [1; zeros(M,1)]; % Form t_0 function

% Set optimization parameters
options_delta = optimset('LargeScale','on','GradObj','on','Hessian','on',...
                         'Display','off','TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',1000,'MaxIter',1000);

delta_SV = (t_X_Xi'*t_X_Xi) \ (N1*t0 - sum(t_X_Xi)');   % Get starting values of delta
f_ipt_crit = @(x)IPT_CRIT(x, t_X_Xi, t0, Q_hat, M, N1); % Compute delta hat
[delta_IPT, fval, exitflag] = fminunc(f_ipt_crit, delta_SV, options_delta);                                         

% ----------------------------------------------------------------------------------- %
% - STEP 3 : SOLVE FOR IPT ESTIMATE OF GAMMA & P-SCORE COEFFICIENTS                 - %
% ----------------------------------------------------------------------------------- %

t_X_Xi              = [ones(N,1) X - repmat(Xi_hat,N,1)];   % Form t(X,Xi) for entire sample
[phi, phi1, phi2]   = IPT_PHI(delta_IPT, t_X_Xi, Q_hat, N); % Values of phi function and derivative at each sample point
gamma_IPT           = sum(D .* phi1 .* DY)/sum(D .* phi1);  % IPT estimate of gamma

% Compute *unnormalized* propensity score coefficients using mapping given
% in the Section 2.3 of the paper
ps_coef_IPT = [(-1/(1-Q_hat))*(delta_IPT(1) - Xi_hat'*delta_IPT(2:end)) + log(Q_hat/(1-Q_hat)); (-1/(1-Q_hat))*delta_IPT(2:end)];

% ----------------------------------------------------------------------------------- %
% - STEP 4 : FORM LARGE SAMPLE VARIANCE-COVARIANCE ESTIMATES                        - %
% ----------------------------------------------------------------------------------- %

% Form moment vector corresponding to full three step procedure
m1 = [D - Q_hat t_X_Xi(:,2:end)]';                                          % 1+M x N matrix of m_1 moments
m2 = repmat(t0,1,N) + (t_X_Xi' .* kron((D .* phi1)',ones(1+M,1)))/Q_hat;    % 1+M x N matrix of m_2 moments
m3 = -(D .* phi1 .* (DY - gamma_IPT))'/Q_hat;                               % 1   x N matrix of m_3 moments
m  = [m1; m2; m3];                                                          % 2(1+M) + 1 x N matrix of moments    
V_m = m*m'/N;                                                               % Variance of moment vector                            

% Form Jacobian matrix for entire parameter: theta = (rho, delta, gamma)
v   = (-(1-Q_hat).^-1)*t_X_Xi*delta_IPT + log(Q_hat/(1-Q_hat));             % N x 1    
p_x = (1+exp(-v)).^-1;                                                      % N x 1    

A   = [((-(1+exp(v)).^-1) .* ((-1/(1-Q_hat)^2)*t_X_Xi*delta_IPT + (1/(Q_hat*(1-Q_hat)))*ones(N,1)))...
       (-repmat((1+exp(v)).^-1,1,M) .* repmat((-1/(1-Q_hat))*([zeros(M,1) -eye(M)]*delta_IPT)',N,1))]';        % 1 + M x N 'A' matrix
   
M1_rho = -eye(1+M);                                                                                            % 1 + M x 1 + M 
M2_rho = ((repmat(D,1,1+M) .* t_X_Xi)' * A')/N - sum(D ./ p_x)*([0 zeros(1,M); zeros(M,1) -eye(M)])/N;         % 1 + M x 1 + M 
M3_rho = ((D .* (DY - gamma_IPT))'*A')/N;                                                                      % 1     x 1 + M 
M2_delta = (repmat((D .* (-1/(1-Q_hat)) .* (1-p_x) ./ p_x),1,1+M) .* t_X_Xi)'*t_X_Xi/N;                        % 1 + M x 1 + M
M3_delta = -((D .* (-1/(1-Q_hat)) .* (1-p_x) ./ p_x) .* (DY - gamma_IPT))'*t_X_Xi/N;                           % 1     x 1 + M
M3_gamma = sum(- D ./ p_x)/N;                                                                                  % 1     x 1
M_full = [M1_rho zeros(1+M,1+M) zeros(1+M,1); M2_rho M2_delta zeros(1+M,1); M3_rho M3_delta M3_gamma];

% Calculate asymptotic variance of gamma
VCOV_theta_IPT   = inv(M_full)*V_m*inv(M_full)';                              % Covariance matrix for entire 2(1+M) + 1 parameter (K=1)
VCOV_gamma_IPT   = VCOV_theta_IPT(end,end);                                   % Variance of gamma_hat alone

% Calculate asymptotic variance matrix for *unnormalized* propensity score
% coefficients
t_X     = [ones(N,1) X];                                                                                       % N x 1 + M regressor matrix (f/ unnormalized p-score)    
M_un    = (-repmat((1+exp(v)).^-1,1,1+M) .* t_X)'*t_X/N;                                                       % 1 + M x 1 + M Jacobian matrix  
m_un    = (repmat((D ./ p_x - 1),1,1+M) .* t_X)';                                                              % 1 + M x N matrix of moments     
V_un    = m_un*m_un'/N;                                                                                        % Variance of moment vector     
VCOV_ps_coef_IPT = inv(M_un)*V_un*inv(M_un)';                                 % Variance of unnormalized propensity score coeffients



