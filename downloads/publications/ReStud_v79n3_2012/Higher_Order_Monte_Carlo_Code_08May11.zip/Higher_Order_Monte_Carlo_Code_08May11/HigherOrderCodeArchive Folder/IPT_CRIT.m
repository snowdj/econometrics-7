function [crit_delta, FOC_delta, SOC_delta] = IPT_CRIT(delta, t_X_Xi, t0, Q, M, N1)

% This function evaluates the IPT criterion function and its first and
% second derivatives as described in Graham, Pinto, and Egel (2011)

[phi, phi1, phi2] = IPT_PHI(delta, t_X_Xi, Q, N1);

crit_delta    = -t0'*delta - sum(phi)/N1;
FOC_delta     = -t0 - sum((t_X_Xi' .* kron(phi1',ones(1+M,1)))')'/N1;
SOC_delta     = -t_X_Xi'*(t_X_Xi' .* kron(phi2',ones(1+M,1)))'/N1;
 