% This is a base m.file which, when run, replicates the "higher order" Monte Carlo 
% experiments reported in the supplemental web appendix of Graham, Pinto 
% and Egel (2011). This file calls AIPW_MCAR.m and IPT_MAR.m. 

rand('state',19);
randn('state',5 );

% ---------------------------------------------------------------------%
% PART I : First set of designs                                       -%  
% ---------------------------------------------------------------------%

B           = 5000;
N           = 1000;
Q           = 0.5;
iI          = 40;

% Design 1
M           = 1;
sigma_u     = sqrt((40 - M)/2);
Q           = 0.5;
asym_se     = sqrt((2*sigma_u^2 + M)/N);
asym_bias   = (-(M/N)*sqrt(8))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = sqrt(1/2)*(random('chi2',ones(N,M)) - 1);
    Y = X*ones(M,1) + random('normal',zeros(N,1),sigma_u*ones(N,1));
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 1
disp('RESULTS FOR M = 1 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);

% Design 2
M           = 5;
sigma_u     = sqrt((40 - M)/2);
Q           = 0.5;
asym_se     = sqrt((2*sigma_u^2 + M)/N);
asym_bias   = (-(M/N)*sqrt(8))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = sqrt(1/2)*(random('chi2',ones(N,M)) - 1);
    Y = X*ones(M,1) + random('normal',zeros(N,1),sigma_u*ones(N,1));
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 2
disp('RESULTS FOR M = 5 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);

% Design 3
M           = 10;
sigma_u     = sqrt((40 - M)/2);
Q           = 0.5;
asym_se     = sqrt((2*sigma_u^2 + M)/N);
asym_bias   = (-(M/N)*sqrt(8))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = sqrt(1/2)*(random('chi2',ones(N,M)) - 1);
    Y = X*ones(M,1) + random('normal',zeros(N,1),sigma_u*ones(N,1));
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 3
disp('RESULTS FOR M = 10 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);

% Design 4
M           = 15;
sigma_u     = sqrt((40 - M)/2);
Q           = 0.5;
asym_se     = sqrt((2*sigma_u^2 + M)/N);
asym_bias   = (-(M/N)*sqrt(8))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = sqrt(1/2)*(random('chi2',ones(N,M)) - 1);
    Y = X*ones(M,1) + random('normal',zeros(N,1),sigma_u*ones(N,1));
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 4
disp('RESULTS FOR M = 15 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);

% Design 5
M           = 20;
sigma_u     = sqrt((40 - M)/2);
Q           = 0.5;
asym_se     = sqrt((2*sigma_u^2 + M)/N);
asym_bias   = (-(M/N)*sqrt(8))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = sqrt(1/2)*(random('chi2',ones(N,M)) - 1);
    Y = X*ones(M,1) + random('normal',zeros(N,1),sigma_u*ones(N,1));
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 6
disp('RESULTS FOR M = 20 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);

% Design 6
M           = 25;
sigma_u     = sqrt((40 - M)/2);
Q           = 0.5;
asym_se     = sqrt((2*sigma_u^2 + M)/N);
asym_bias   = (-(M/N)*sqrt(8))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = sqrt(1/2)*(random('chi2',ones(N,M)) - 1);
    Y = X*ones(M,1) + random('normal',zeros(N,1),sigma_u*ones(N,1));
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 6
disp('RESULTS FOR M = 25 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);
  
% ---------------------------------------------------------------------%
% PART II : Second set of designs                                     -%  
% ---------------------------------------------------------------------%

B           = 5000;
N           = 1000;
iI          = 40;

% Design 1
Q           = 0.8;
sigma_x     = 2;
sigma_u     = sqrt(Q*(iI - 2*sigma_x^4));
asym_se     = sqrt(iI/N);
asym_bias   = -((1/N)*((1-Q)/Q)*(6*sigma_x^2))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = random('normal',zeros(N,1),sigma_x*ones(N,1));
    Y = -sigma_x^2 + X.^2 + random('normal',zeros(N,1),sigma_u*ones(N,1));
    X = [X X.^2];
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 1
disp('RESULTS FOR Q = 0.8 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);

% Design 2
Q           = 0.6;
sigma_x     = 2;
sigma_u     = sqrt(Q*(iI - 2*sigma_x^4));
asym_se     = sqrt(iI/N);
asym_bias   = -((1/N)*((1-Q)/Q)*(6*sigma_x^2))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = random('normal',zeros(N,1),sigma_x*ones(N,1));
    Y = -sigma_x^2 + X.^2 + random('normal',zeros(N,1),sigma_u*ones(N,1));
    X = [X X.^2];
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 2
disp('RESULTS FOR Q = 0.6 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);
  
% Design 3
Q           = 0.4;
sigma_x     = 2;
sigma_u     = sqrt(Q*(iI - 2*sigma_x^4));
asym_se     = sqrt(iI/N);
asym_bias   = -((1/N)*((1-Q)/Q)*(6*sigma_x^2))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = random('normal',zeros(N,1),sigma_x*ones(N,1));
    Y = -sigma_x^2 + X.^2 + random('normal',zeros(N,1),sigma_u*ones(N,1));
    X = [X X.^2];
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 3
disp('RESULTS FOR Q = 0.4 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);
  
% Design 4
Q           = 0.2;
sigma_x     = 2;
sigma_u     = sqrt(Q*(iI - 2*sigma_x^4));
asym_se     = sqrt(iI/N);
asym_bias   = -((1/N)*((1-Q)/Q)*(6*sigma_x^2))/asym_se;

MC_Results_AIPW  = zeros(B,2);
MC_Results_IPT  = zeros(B,3);

for b = 1:B
    X = random('normal',zeros(N,1),sigma_x*ones(N,1));
    Y = -sigma_x^2 + X.^2 + random('normal',zeros(N,1),sigma_u*ones(N,1));
    X = [X X.^2];
    D = (random('unif',zeros(N,1),ones(N,1)) <= Q);
    DY = D .* Y;
    [gamma_AIPW VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);
    [gamma_IPT, VCOV_gamma_IPT, exitflag] = IPT_MAR(D,DY,X);
    MC_Results_AIPW(b,:) = [gamma_AIPW/asym_se sqrt(VCOV_gamma_AIPW/N)];
    MC_Results_IPT(b,:) = [gamma_IPT/asym_se sqrt(VCOV_gamma_IPT/N) exitflag];
end

% Results for Design 4
disp('RESULTS FOR Q = 0.2 DESIGN')
disp('A: AIPW')
disp('bias_A se_A bias_MC se_MC sd_MC coverage');
disp([asym_bias asym_se median(MC_Results_AIPW) std(asym_se*MC_Results_AIPW(:,1))...
      mean((MC_Results_AIPW(:,1)*asym_se-1.96*MC_Results_AIPW(:,2)<=0) .* (MC_Results_AIPW(:,1)*asym_se+1.96*MC_Results_AIPW(:,2)>0))]);
disp('B: IPT')
disp('bias_A se_A bias_MC se_MC sd_MC coverage FracSuccessfulRep');
disp([0 asym_se median(MC_Results_IPT(:,1:2)) std(asym_se*MC_Results_IPT(:,1))... 
      mean((MC_Results_IPT(:,1)*asym_se-1.96*MC_Results_IPT(:,2)<=0) .* (MC_Results_IPT(:,1)*asym_se+1.96*MC_Results_IPT(:,2)>0))...
      mean((MC_Results_IPT(:,3)>=1))]);  

