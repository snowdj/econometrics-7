function [gamma_AIPW, VCOV_gamma_AIPW] = AIPW_MCAR(D,DY,X,Q);

% This function computes the mean on an outcome variable, Y, when
% it is missing completely at random (MCAR) by the AIPW estimator of Newey (1994)

% INPUTS
% D     : N x 1 vector with ith element equal to 1 if ith unit's Y is observed
%         and zero otherwise
% DY    : D*Y, with Y the N x 1 vector of outcomes
% X     : X, N x M matrix of covariates

% OUTPUTS

% ----------------------------------------------------------------------------------- %
% - STEP 1 : ORGANIZE DATA                                                          - %
% ----------------------------------------------------------------------------------- %

N       = length(D);      % Number of units in sample  
M       = size(X,2);      % Dimension of X
t_X     = [ones(N,1) X];  % Form t(X) matrix (N x 1+M)

% ----------------------------------------------------------------------------------- %
% - STEP 2 : SOLVE ITERATED GMM PROBLEM                                             - %
% ----------------------------------------------------------------------------------- %

m2      =   (mean(repmat(D/Q - 1,1,M+1) .* t_X))'; % M + 1  x 1 sample mean of auxiliary moments
V_22    =   ((t_X'*t_X)/N);
w_AIPW  =   (D/Q) .* (1-t_X*inv(V_22)*m2);
w_AIPW  =   w_AIPW/sum(w_AIPW); 
gamma_AIPW = sum(w_AIPW .* DY);

% ----------------------------------------------------------------------------------- %
% - STEP 3 : Estimate sampling variance                                             - %
% ----------------------------------------------------------------------------------- %

V_11 = mean(D .* (DY - gamma_AIPW).^2)/Q^2;
V_12 = mean(repmat(D .* (DY - gamma_AIPW),1,M+1) .* t_X)/Q;
VCOV_gamma_AIPW = V_11 - V_12*inv(V_22)*V_12';
