function [beta_PL VCOV_beta_PL exitflag] = PAIRWISE_LOGIT(W,X,M,silent)

% This function computes pairwise logit estimates of a one-to-one
% two sided transferable utility model as described in Graham (2010)

%-------------------------------------------------------------------------%
%- STEP 1 : PREPARE DATA FOR ESTIMATION                                  -%
%-------------------------------------------------------------------------%

N = length(W);
K = length(unique(W));
L = length(unique(X));

firm_pairs = combnk(1:K,2);
worker_pairs = combnk(1:L,2);
Jf = length(firm_pairs);
Jw = length(worker_pairs);
[J d_M] = size(M);

n = (1/2)*N*(N-1);

% Calculate assortativeness indicators for all match pairs
WW    = repmat(W,1,N);
XX    = repmat(X,1,N);
S     = sign((WW - WW') .* (XX - XX'));   

% Calculate suballocation memberships for all match pairs
A = zeros(N,N,J);     
for km = 1:Jf
    for ln = 1:Jw
        A(:,:,(km-1)*Jw+ln) = ((WW==firm_pairs(km,1))+(WW==firm_pairs(km,2))).*((WW'==firm_pairs(km,1))+(WW'==firm_pairs(km,2))) ...
                           .*((XX==worker_pairs(ln,1))+(XX==worker_pairs(ln,2))).*((XX'==worker_pairs(ln,1))+(XX'==worker_pairs(ln,2)));            
    end
end

% prepare data for estimation using a standard logit program
S_ij = reshape(tril(S,-1),N^2,1);
AM_ij = zeros(N^2,d_M);
for km = 1:Jf
    for ln = 1:Jw
        AM_ij = AM_ij + repmat(reshape(tril(A(:,:,(km-1)*Jw+ln),-1),N^2,1),1,d_M) .* repmat(M((km-1)*Jw+ln,:),N^2,1);         
    end
end

% drop all pairs that are not assortative or anti-assortative
g = find(S_ij~=0);
S_ij_t = S_ij(g);
D_ij_t = 0*(S_ij_t==-1) + 1*(S_ij_t==1);
AM_ij_t = AM_ij(g,:);

%-------------------------------------------------------------------------%
%- STEP 2 : COMPUTE POINT ESTIMATES FOR BETA                             -%
%-------------------------------------------------------------------------%

[beta_PL, exitflag] = PAIRWISE_LOGIT_EST(D_ij_t,AM_ij_t,silent);

clear g S_ij_t D_ij_t AM_ij_t;

%-------------------------------------------------------------------------%
%- STEP 3 : COMPUTE VARIANCE-COVARIANCE MATRIX                           -%
%-------------------------------------------------------------------------%

% compute `logit prob' for all pairs
index_ij = zeros(N,N);
Mbeta_PL = M*beta_PL;
for km = 1:Jf
    for ln = 1:Jw
       index_ij = index_ij + A(:,:,(km-1)*Jw+ln)*Mbeta_PL((km-1)*Jw+ln);
    end
end

resid_ij = abs(S).*((S==1) - (1+exp(-index_ij)).^-1);

s_ur_i = zeros(J,N);
H_ur_hat   = zeros(J,J);

for km = 1:Jf
    for ln = 1:Jw
       s_ur_i((km-1)*Jw+ln,:) = sum((resid_ij .* A(:,:,(km-1)*Jw+ln))')/(N-1);
       H_ur_hat((km-1)*Jw+ln,(km-1)*Jw+ln) = sum(sum(tril(-abs(S).* (exp(index_ij) ./ (1+exp(index_ij)).^2) .* A(:,:,(km-1)*Jw+ln),-1)))/n;
    end
end

s_i = M'*s_ur_i;
H_hat = M'*H_ur_hat*M;

OMEGA_hat   = (s_i*s_i')/N;
iGAMMA_hat  = inv(H_hat);
VCOV_beta_PL = 4*iGAMMA_hat*OMEGA_hat*iGAMMA_hat;




