
% This M.file replicates the Monte Carlo results contained in my Handbook
% of Social Economics chapter "Econometric methods for the analysis of
% assignment problems in the presence of complementarity and social
% spillovers"

% This file calls, directly or indirectly, the following functions
% [1] Matching_Monte_Carlo_DGP()
% [2] PAIRWISE_LOGIT()
% [3] PAIRWISE_LOGIT_EST()
% [4] LOGIT_LOGL()

% Please e-mail me with any comments/suggestions: bsg1@nyu.edu. I regret
% that I am unable to provide instruction/support regarding the use of
% these files.

MC = 10;
N  = 1000;

% Define DGP # 1

p = [1/3; 1/3; 1/3];
q = [1/3; 1/3; 1/3];

a = [1; 2; 3];
b = [1; 2; 3];
W = [1; 2; 3];
X = [1; 2; 3];

beta1 = 1;

delta = repmat(a,1,3) + repmat(b',3,1) + beta1*W*X'
M = [1 2 1 2 4 2 1 2 1]';

[MC_Results1] = Matching_Monte_Carlo_DGP(delta,beta,M,p,q,N,MC);

% Define DGP # 2

p = [1/3; 1/3; 1/3];
q = [1/3; 1/3; 1/3];

a = [0 0 0]';
b = [0 0 0]';
W = [1; 2; 3;];
X = [1; 2; 3;];

beta1 = 1;
beta2 = -2;
beta = [beta1; beta2];

delta = repmat(a,1,3) + repmat(b',3,1) + beta1*W*X' + beta2*([0 0 0; 0 0 0; 0 0 1])
M = [1 0; 2 0; 1 0; 2 0; 4 1; 2 1; 1 0; 2 1; 1 1];

[MC_Results2] = Matching_Monte_Carlo_DGP(delta,beta,M,p,q,N,MC);
