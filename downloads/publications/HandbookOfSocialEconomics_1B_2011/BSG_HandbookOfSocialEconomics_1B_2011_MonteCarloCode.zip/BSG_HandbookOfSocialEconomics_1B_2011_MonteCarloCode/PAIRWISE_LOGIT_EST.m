function [phi_PL, exitflag] = PAIRWISE_LOGIT_EST(D,X,silent);

% This function is called by the PAIRWISE_LOGIT function. It is a
% standard implementation of LOGIT ML.

% INPUTS
% D     : N x 1 vector of binary outcomes
% X     : X is a matrix of covariates (without a constant)
% silent: when silent = 1 optimization output is suppressed

% OUTPUTS
% phi_PL         : estimates of logit coefficients


[N K] = size(X);        % Number of observations and covariates
f_logit_logl = @(x)LOGIT_LOGL(x, D, X, K);  % define objective function

% Set optimization parameters
if silent == 1
    % Use fisher-scoring with lower tolerances
    options_phi = optimset('LargeScale','on','GradObj','on','Hessian','on',...
                           'Display','off','TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',1000,'MaxIter',1000);
    phi_SV = (X'*X) \ (X'*D);                                 % Linear probability starting values for logit          
else
    % Take a few fisher-scoring steps to get starting values, then do a
    % quasi-newton search
    options_phi = optimset('LargeScale','on','GradObj','on','Hessian','on',...
                           'Display','iter','TolFun',1e-6,'TolX',1e-6,'MaxFunEvals',10,'MaxIter',10); 
    
    phi_SV = fminunc(f_logit_logl,  zeros(K,1), options_phi); 
    
    options_phi = optimset('LargeScale','off','GradObj','on','Hessian','off',...
                           'Display','iter','TolFun',1e-25,'TolX',1e-12,'MaxFunEvals',10000,'MaxIter',10000); 
    
end                                      

[phi_PL,LOGL,exitflag,output,SCORE,HESS] = fminunc(f_logit_logl, phi_SV, options_phi);  % estimate delta_ML    
