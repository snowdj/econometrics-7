function [LOGL, SCORE, INFO] = LOGIT_LOGL(delta,D,X,K)

exp_Xdelta  = exp(X*delta);
LOGL        = -(sum(D .* (X*delta)) - sum(log(1+exp_Xdelta)));
SCORE       = -(X'*(D - (exp_Xdelta ./ (1+exp_Xdelta))));
INFO        = -((repmat((exp_Xdelta ./ (1+exp_Xdelta).^2),1,K) .* X)'*X);