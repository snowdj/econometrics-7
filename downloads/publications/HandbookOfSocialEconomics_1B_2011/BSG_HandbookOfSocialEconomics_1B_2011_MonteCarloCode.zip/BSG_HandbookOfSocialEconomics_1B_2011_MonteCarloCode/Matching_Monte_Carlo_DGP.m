function [MC_Results] = Matching_Monte_Carlo_DGP(delta,beta,M,p,q,N,MC)

%-------------------------------------------------------------------------%
%- STEP 1 : COMPUTE POPULATION ALCs                                      -%
%-------------------------------------------------------------------------%

[K L] = size(delta);

firm_pairs = combnk(1:K,2);
worker_pairs = combnk(1:L,2);
Jf = length(firm_pairs);
Jw = length(worker_pairs);
phi = zeros(Jf*Jw,1);

for km = 1:Jf
    for ln = 1:Jw
        phi((km-1)*Jw+ln) = delta(firm_pairs(km,2),worker_pairs(ln,2)) - delta(firm_pairs(km,2),worker_pairs(ln,1)) ...
                         - (delta(firm_pairs(km,1),worker_pairs(ln,2)) - delta(firm_pairs(km,1),worker_pairs(ln,1)));            
    end
end

%-------------------------------------------------------------------------%
%- STEP 2 : SOLVE FOR EQUILIBRIUM ASSIGNMENT                             -%
%-------------------------------------------------------------------------%

% Here I solve for the equilibrium allocation using the algorithmn
% described by Galichon and Salanie (2009, Section 6). Here I use r in
% place of their pi and s in place of their r. 

% Compute s(w,x) 
s = [p(1)*q(1)*exp(delta(1,1));...
     p(1)*q(2)*exp(delta(1,2));...
     p(1)*q(3)*exp(delta(1,3));...
     p(2)*q(1)*exp(delta(2,1));...
     p(2)*q(2)*exp(delta(2,2));...
     p(2)*q(3)*exp(delta(2,3));...
     p(3)*q(1)*exp(delta(3,1));...
     p(3)*q(2)*exp(delta(3,2));... 
     p(3)*q(3)*exp(delta(3,3))];...
s = s/sum(s);   % normalize to sum to one

% Iterative Projection Fitting Procedure
A_j = p;

for j = 1:1000  %Use a 1000 iterations to be sure a fixed point has been reached   
    B_jp1_1 = q(1)/(s(1)*A_j(1) + s(4)*A_j(2) + s(7)*A_j(3));
    B_jp1_2 = q(2)/(s(2)*A_j(1) + s(5)*A_j(2) + s(8)*A_j(3)); 
    B_jp1_3 = q(3)/(s(3)*A_j(1) + s(6)*A_j(2) + s(9)*A_j(3));
    B_j     = [B_jp1_1; B_jp1_2; B_jp1_3;]; 
    A_jp1_1 = p(1)/(s(1)*B_j(1) + s(2)*B_j(2) + s(3)*B_j(3));
    A_jp1_2 = p(2)/(s(4)*B_j(1) + s(5)*B_j(2) + s(6)*B_j(3)); 
    A_jp1_3 = p(3)/(s(7)*B_j(1) + s(8)*B_j(2) + s(9)*B_j(3));
    A_j     = [A_jp1_1; A_jp1_2; A_jp1_3]; 
end

% Recover the equilibrium allocation
r = [s(1)*A_j(1)*B_j(1);...
     s(2)*A_j(1)*B_j(2);...
     s(3)*A_j(1)*B_j(3);...
     s(4)*A_j(2)*B_j(1);...
     s(5)*A_j(2)*B_j(2);...
     s(6)*A_j(2)*B_j(3);...
     s(7)*A_j(3)*B_j(1);...
     s(8)*A_j(3)*B_j(2);...
     s(9)*A_j(3)*B_j(3);];

% Verify that the equilibrium assignment is feasible
R  = reshape(r,3,3)';
Ra = [R         sum(R,2);
      sum(R,1)  sum(sum(R,1))];
disp('Equilibrium Assignment')
disp(Ra);
clear R Ra;

% Verify that is satifies the CS/GS equilibrium conditions
disp([r(1) (r(7)/r(9))*r(3)*exp(delta(3,3) - delta(3,1) - (delta(1,3) - delta(1,1)));...
      r(2) (r(8)/r(9))*r(3)*exp(delta(3,3) - delta(3,2) - (delta(1,3) - delta(1,2)));...
      r(4) (r(7)/r(9))*r(6)*exp(delta(3,3) - delta(3,1) - (delta(2,3) - delta(2,1)));...
      r(5) (r(8)/r(9))*r(6)*exp(delta(3,3) - delta(3,2) - (delta(2,3) - delta(2,2)))]);
  
%-------------------------------------------------------------------------%
%- STEP 3 : SIMULATE MC DATASETS                                         -%
%-------------------------------------------------------------------------%

silent = 0;
t = cumsum(r);
J = length(beta);
MC_Results = zeros(MC,3*J+1);

for mc = 1:MC
    u = random('unif',zeros(N,1),ones(N,1));
    W = 1*(u<=t(3)) +  2*(u>t(3)).*(u<=t(6)) +  3*(u>t(6));
    X = 1*(u<=t(1)) +  1*(u>t(3)).*(u<=t(4)) +  1*(u>t(6)).*(u<=t(7)) + ...
        2*(u>t(1)).*(u<=t(2)) +  2*(u>t(4)).*(u<=t(5)) +  2*(u>t(7)).*(u<=t(8)) + ...
        3*(u>t(2)).*(u<=t(3)) +  3*(u>t(5)).*(u<=t(6)) +  3*(u>t(8)).*(u<=t(9));    
    [beta_PL VCOV_beta_PL exitflag] = PAIRWISE_LOGIT(W,X,M,silent);
    beta_PL_se = sqrt(diag(VCOV_beta_PL/N));
    coverage = ((beta_PL-1.96*beta_PL_se)<=beta).*((beta_PL+1.96*beta_PL_se)>=beta);    
    exitflag = (exitflag>0);
    MC_Results(mc,:) = [beta_PL' beta_PL_se' coverage' exitflag];
end

disp('beta mean(beta_hat) median(beta_hat) std(beta_hat) mean(se_beta_hat) median(se_beta_hat) coverage successful_opt');
disp([beta mean(MC_Results(:,1:J))' median(MC_Results(:,1:J))' std(MC_Results(:,1:J))' mean(MC_Results(:,(J+1):(2*J)))'...
      median(MC_Results(:,(J+1):(2*J)))' mean(MC_Results(:,(2*J+1):(3*J)))' [mean(MC_Results(:,end)); zeros(J-1,1)]])    
    

